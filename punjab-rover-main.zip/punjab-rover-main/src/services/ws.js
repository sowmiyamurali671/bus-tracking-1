// WebSocket service for real-time bus tracking
// TODO: Replace mock implementation with actual WebSocket connection

class WebSocketService {
  constructor() {
    this.socket = null;
    this.isConnected = false;
    this.subscribers = new Map();
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
    
    // TODO: Replace with actual WebSocket server URL
    this.wsUrl = 'ws://localhost:3001/ws';
  }

  // Connect to WebSocket server
  connect() {
    // TODO: Implement real WebSocket connection
    // this.socket = new WebSocket(this.wsUrl);
    
    // Mock implementation for development
    console.log('🚌 [Mock WebSocket] Connecting to bus tracking server...');
    
    // Simulate connection after delay
    setTimeout(() => {
      this.isConnected = true;
      console.log('🚌 [Mock WebSocket] Connected successfully');
      
      // Start mock data streaming
      this.startMockDataStream();
      
      // Notify connection subscribers
      this.notifySubscribers('connection', { status: 'connected' });
    }, 1000);

    // TODO: Uncomment for real WebSocket implementation
    /*
    this.socket.onopen = () => {
      console.log('WebSocket connected');
      this.isConnected = true;
      this.reconnectAttempts = 0;
    };

    this.socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      this.handleMessage(data);
    };

    this.socket.onclose = () => {
      console.log('WebSocket disconnected');
      this.isConnected = false;
      this.attemptReconnect();
    };

    this.socket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    */
  }

  // Disconnect from WebSocket
  disconnect() {
    if (this.socket) {
      this.socket.close();
    }
    this.isConnected = false;
    this.clearMockTimers();
    console.log('🚌 [Mock WebSocket] Disconnected');
  }

  // Subscribe to bus location updates
  subscribeToBus(busId, callback) {
    const topic = `bus/${busId}`;
    
    if (!this.subscribers.has(topic)) {
      this.subscribers.set(topic, new Set());
    }
    this.subscribers.get(topic).add(callback);

    // TODO: Send subscription message to real WebSocket server
    // this.send({
    //   type: 'subscribe',
    //   topic: topic
    // });

    console.log(`🚌 [Mock WebSocket] Subscribed to ${topic}`);

    // Return unsubscribe function
    return () => {
      this.unsubscribeFromBus(busId, callback);
    };
  }

  // Unsubscribe from bus updates
  unsubscribeFromBus(busId, callback) {
    const topic = `bus/${busId}`;
    
    if (this.subscribers.has(topic)) {
      this.subscribers.get(topic).delete(callback);
      
      // Clean up empty subscription sets
      if (this.subscribers.get(topic).size === 0) {
        this.subscribers.delete(topic);
        
        // TODO: Send unsubscription message to real server
        // this.send({
        //   type: 'unsubscribe', 
        //   topic: topic
        // });
      }
    }

    console.log(`🚌 [Mock WebSocket] Unsubscribed from ${topic}`);
  }

  // Send message to WebSocket server
  send(message) {
    if (this.isConnected && this.socket) {
      // TODO: Uncomment for real implementation
      // this.socket.send(JSON.stringify(message));
      
      console.log('🚌 [Mock WebSocket] Sending:', message);
    } else {
      console.warn('🚌 [Mock WebSocket] Cannot send message - not connected');
    }
  }

  // Handle incoming WebSocket messages
  handleMessage(data) {
    const { type, topic, payload } = data;

    switch (type) {
      case 'bus_location_update':
        this.notifySubscribers(topic, payload);
        break;
      
      case 'bus_status_change':
        this.notifySubscribers(topic, payload);
        break;
        
      case 'driver_connected':
        this.notifySubscribers('driver_events', payload);
        break;
        
      default:
        console.log('🚌 [WebSocket] Unknown message type:', type);
    }
  }

  // Notify all subscribers of a topic
  notifySubscribers(topic, data) {
    if (this.subscribers.has(topic)) {
      this.subscribers.get(topic).forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error('Error in WebSocket subscriber callback:', error);
        }
      });
    }
  }

  // Mock data streaming for development
  startMockDataStream() {
    // TODO: Remove this mock implementation when connecting to real server
    
    this.mockTimers = [];
    
    // Simulate bus location updates every 5 seconds
    const locationTimer = setInterval(() => {
      const busIds = ['BUS001', 'BUS002', 'BUS003', 'BUS004', 'BUS005'];
      
      busIds.forEach(busId => {
        // Generate random location change
        const mockUpdate = {
          busId,
          location: {
            lat: 30.7333 + (Math.random() - 0.5) * 0.1,
            lng: 76.7794 + (Math.random() - 0.5) * 0.1
          },
          speed: Math.floor(Math.random() * 60) + 20,
          timestamp: Date.now(),
          nextStop: 'Mock Stop',
          eta: `${Math.floor(Math.random() * 30) + 5} min`
        };

        this.notifySubscribers(`bus/${busId}`, mockUpdate);
      });
    }, 5000);

    this.mockTimers.push(locationTimer);

    // Simulate occasional status changes
    const statusTimer = setInterval(() => {
      const busId = `BUS00${Math.floor(Math.random() * 5) + 1}`;
      const statuses = ['available', 'unavailable', 'maintenance'];
      
      const statusUpdate = {
        busId,
        status: statuses[Math.floor(Math.random() * statuses.length)],
        timestamp: Date.now()
      };

      this.notifySubscribers(`bus/${busId}`, statusUpdate);
    }, 30000);

    this.mockTimers.push(statusTimer);
  }

  // Clear mock timers
  clearMockTimers() {
    if (this.mockTimers) {
      this.mockTimers.forEach(timer => clearInterval(timer));
      this.mockTimers = [];
    }
  }

  // Attempt to reconnect on connection loss
  attemptReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delay = Math.pow(2, this.reconnectAttempts) * 1000; // Exponential backoff
      
      console.log(`🚌 [WebSocket] Attempting to reconnect in ${delay/1000}s (attempt ${this.reconnectAttempts})`);
      
      setTimeout(() => {
        this.connect();
      }, delay);
    } else {
      console.error('🚌 [WebSocket] Max reconnection attempts reached');
    }
  }

  // Get connection status
  getConnectionStatus() {
    return {
      isConnected: this.isConnected,
      subscriberCount: this.subscribers.size
    };
  }
}

// Export singleton instance
export default new WebSocketService();

// Example usage:
/*
import wsService from './services/ws.js';

// Connect to WebSocket
wsService.connect();

// Subscribe to bus updates
const unsubscribe = wsService.subscribeToBus('BUS001', (data) => {
  console.log('Bus update received:', data);
  // Update UI with new bus location/status
});

// Later, unsubscribe
unsubscribe();

// Disconnect when app closes
wsService.disconnect();
*/