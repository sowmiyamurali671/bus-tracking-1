import { buses, drivers, adminUsers, getBusById, getDriverById } from '../data/seed.js';

// Mock API service for Punjab Bus Tracking
// TODO: Replace all mock implementations with real API endpoints
// NOTE: Now integrated with AppContext for real-time updates

// Helper to get app context (will be set by components)
let appActions = null;
let appState = null;

export const setAppContext = (actions, state) => {
  appActions = actions;
  appState = state;
};

class ApiService {
  constructor() {
    this.baseUrl = 'http://localhost:3001/api'; // TODO: Replace with actual API URL
    this.token = localStorage.getItem('authToken');
  }

  // Authentication helpers
  setToken(token) {
    this.token = token;
    localStorage.setItem('authToken', token);
  }

  getAuthHeaders() {
    return {
      'Content-Type': 'application/json',
      ...(this.token && { 'Authorization': `Bearer ${this.token}` })
    };
  }

  // Bus search functionality
  async searchBuses(fromLat, fromLng, toLocation) {
    return new Promise((resolve) => {
      setTimeout(() => {
        // Use state from context if available
        const busesData = appState ? appState.buses : buses;
        
        // Filter buses that have stops near the destination
        const filteredBuses = busesData.filter(bus => {
          return bus.stops.some(stop => 
            stop.name.toLowerCase().includes(toLocation.toLowerCase()) ||
            toLocation.toLowerCase().includes(stop.name.toLowerCase().split(' ')[0])
          );
        });

        // Calculate ETA based on distance from current location
        const busesWithETA = filteredBuses.map(bus => {
          const distanceFromPassenger = Math.sqrt(
            Math.pow(bus.currentLocation.lat - fromLat, 2) + 
            Math.pow(bus.currentLocation.lng - fromLng, 2)
          ) * 111; // Rough km conversion

          const estimatedETA = Math.round(distanceFromPassenger / (bus.speed || 40) * 60);
          
          return {
            ...bus,
            etaToPassenger: `${estimatedETA} min`
          };
        });

        // Log the search if context is available
        if (appActions) {
          const status = busesWithETA.length > 0 ? 'success' : 'failed';
          appActions.logSearch('Current Location', toLocation, fromLat, fromLng, status);
        }

        resolve({
          success: true,
          data: busesWithETA
        });
      }, 800);
    });
  }

  // Get detailed bus information
  async getBusDetails(busId) {
    return new Promise((resolve) => {
      setTimeout(() => {
        const busesData = appState ? appState.buses : buses;
        const bus = busesData.find(b => b.id === busId);
        
        if (bus) {
          resolve({
            success: true,
            data: bus
          });
        } else {
          resolve({
            success: false,
            error: 'Bus not found'
          });
        }
      }, 300);
    });
  }

  // Driver authentication
  async driverLogin(credentials) {
    return new Promise((resolve) => {
      setTimeout(() => {
        const driversData = appState ? appState.drivers : drivers;
        const driver = driversData.find(d => 
          d.username === credentials.username && 
          d.password === credentials.password
        );

        if (driver) {
          const token = driver.id; // Simple token for demo
          resolve({
            success: true,
            data: {
              driver,
              token,
              type: 'driver'
            }
          });
        } else {
          resolve({
            success: false,
            error: 'Invalid credentials'
          });
        }
      }, 1000);
    });
  }

  // Admin authentication
  async adminLogin(credentials) {
    return new Promise((resolve) => {
      setTimeout(() => {
        const adminData = appState ? appState.adminUsers : adminUsers;
        const admin = adminData.find(a => 
          a.username === credentials.username && 
          a.password === credentials.password
        );

        if (admin) {
          const token = admin.id; // Simple token for demo
          resolve({
            success: true,
            data: {
              admin,
              token,
              type: 'admin'
            }
          });
        } else {
          resolve({
            success: false,
            error: 'Invalid credentials'
          });
        }
      }, 1000);
    });
  }

  // Connect driver to bus
  async connectDriverToBus(busId, driverToken, location = null) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appActions) {
          appActions.connectDriverToBus(busId, driverToken);
          
          if (location) {
            appActions.updateBusLocation(busId, location.lat, location.lng, 0);
          }
          
          resolve({
            success: true,
            message: 'Successfully connected to bus and started GPS tracking',
            data: { busId, status: 'connected', location }
          });
        } else {
          // Fallback
          const bus = getBusById(busId);
          if (bus && !bus.driver) {
            if (location) {
              bus.currentLocation = location;
              bus.lastSeen = new Date().toISOString();
            }
            
            resolve({
              success: true,
              message: 'Successfully connected to bus and started GPS tracking',
              data: { busId, status: 'connected', location }
            });
          } else {
            resolve({
              success: false,
              error: bus ? 'Bus already has a driver' : 'Bus not found'
            });
          }
        }
      }, 500);
    });
  }

  // Update bus location (for real-time tracking)
  async updateBusLocation(busId, lat, lng, speed = 0) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appActions) {
          appActions.updateBusLocation(busId, lat, lng, speed);
          resolve({
            success: true,
            message: 'Bus location updated successfully'
          });
        } else {
          // Fallback
          const bus = getBusById(busId);
          if (bus) {
            bus.currentLocation = { lat, lng };
            bus.lastSeen = new Date().toISOString();
            if (speed !== undefined) {
              bus.speed = speed;
            }
            resolve({
              success: true,
              message: 'Bus location updated successfully'
            });
          } else {
            resolve({
              success: false,
              error: 'Bus not found'
            });
          }
        }
      }, 200);
    });
  }

  // Search buses by registration number
  async searchBusByRegistration(registrationNo) {
    return new Promise((resolve) => {
      setTimeout(() => {
        const busesData = appState ? appState.buses : buses;
        const filteredBuses = busesData.filter(bus => 
          bus.registrationNo && 
          bus.registrationNo.toLowerCase().includes(registrationNo.toLowerCase())
        );
        
        resolve({
          success: true,
          data: filteredBuses
        });
      }, 500);
    });
  }

  // Admin: Add new driver
  async addDriver(driverData) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appActions) {
          appActions.addDriver(driverData);
          resolve({
            success: true,
            message: 'Driver added successfully'
          });
        } else {
          // Fallback
          const newDriver = {
            id: `DRV${Date.now()}`,
            ...driverData,
            currentBus: null,
            isActive: true
          };
          
          resolve({
            success: true,
            data: newDriver,
            message: 'Driver added successfully'
          });
        }
      }, 800);
    });
  }

  // Admin: Add new bus
  async addBus(busData) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appActions) {
          appActions.addBus(busData);
          resolve({
            success: true,
            message: 'Bus added successfully'
          });
        } else {
          // Fallback
          const newBus = {
            id: `BUS${Date.now()}`,
            ...busData,
            currentLocation: busData.stops[0] ? { lat: busData.stops[0].lat, lng: busData.stops[0].lng } : null,
            speed: 0,
            nextStop: busData.stops[1]?.name || null,
            lastStopCrossed: null,
            eta: "0 min",
            isAvailable: true,
            lastSeen: new Date().toISOString(),
            driver: null
          };

          resolve({
            success: true,
            data: newBus,
            message: 'Bus added successfully'
          });
        }
      }, 800);
    });
  }

  // Admin: Get all buses
  async getAllBuses() {
    return new Promise((resolve) => {
      setTimeout(() => {
        const busesData = appState ? appState.buses : buses;
        resolve({
          success: true,
          data: busesData
        });
      }, 500);
    });
  }

  // Admin: Update bus availability
  async updateBusAvailability(busId, isAvailable) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appActions) {
          appActions.toggleBusAvailability(busId, isAvailable);
          resolve({
            success: true,
            message: `Bus ${isAvailable ? 'marked as available' : 'marked as unavailable'}`
          });
        } else {
          // Fallback
          const bus = getBusById(busId);
          if (bus) {
            bus.isAvailable = isAvailable;
            resolve({
              success: true,
              message: `Bus ${isAvailable ? 'marked as available' : 'marked as unavailable'}`
            });
          } else {
            resolve({
              success: false,
              error: 'Bus not found'
            });
          }
        }
      }, 500);
    });
  }

  // Admin: Assign device MAC to bus
  async assignDeviceToBus(busId, deviceMac) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appActions) {
          appActions.assignDevice(busId, deviceMac);
          resolve({
            success: true,
            message: 'Device assigned successfully'
          });
        } else {
          // Fallback
          const bus = getBusById(busId);
          if (bus) {
            bus.deviceMac = deviceMac;
            resolve({
              success: true,
              message: 'Device assigned successfully'
            });
          } else {
            resolve({
              success: false,
              error: 'Bus not found'
            });
          }
        }
      }, 500);
    });
  }

  // Get all drivers (admin function)
  async getAllDrivers() {
    return new Promise((resolve) => {
      setTimeout(() => {
        const driversData = appState ? appState.drivers : drivers;
        resolve({
          success: true,
          data: driversData
        });
      }, 500);
    });
  }

  // Driver: Update location
  async updateDriverLocation(lat, lng) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          message: 'Location updated successfully'
        });
      }, 200);
    });
  }

  // Admin: Delete driver
  async deleteDriver(driverId) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appActions) {
          appActions.deleteDriver(driverId);
          resolve({
            success: true,
            message: 'Driver deleted successfully'
          });
        } else {
          // Fallback
          const driverIndex = drivers.findIndex(d => d.id === driverId);
          if (driverIndex !== -1) {
            drivers.splice(driverIndex, 1);
            resolve({
              success: true,
              message: 'Driver deleted successfully'
            });
          } else {
            resolve({
              success: false,
              error: 'Driver not found'
            });
          }
        }
      }, 500);
    });
  }

  // Admin: Update driver
  async updateDriver(driverId, driverData) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appActions) {
          appActions.editDriver(driverId, driverData);
          resolve({
            success: true,
            message: 'Driver updated successfully'
          });
        } else {
          // Fallback
          const driver = drivers.find(d => d.id === driverId);
          if (driver) {
            Object.assign(driver, driverData);
            resolve({
              success: true,
              data: driver,
              message: 'Driver updated successfully'
            });
          } else {
            resolve({
              success: false,
              error: 'Driver not found'
            });
          }
        }
      }, 500);
    });
  }

  // Admin: Edit bus
  async editBus(busId, busData) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appActions) {
          appActions.editBus(busId, busData);
          resolve({
            success: true,
            message: 'Bus updated successfully'
          });
        } else {
          // Fallback
          const bus = buses.find(b => b.id === busId);
          if (bus) {
            Object.assign(bus, busData);
            resolve({
              success: true,
              data: bus,
              message: 'Bus updated successfully'
            });
          } else {
            resolve({
              success: false,
              error: 'Bus not found'
            });
          }
        }
      }, 500);
    });
  }

  // Admin: Delete bus
  async deleteBus(busId) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appActions) {
          appActions.deleteBus(busId);
          resolve({
            success: true,
            message: 'Bus deleted successfully'
          });
        } else {
          // Fallback
          const busIndex = buses.findIndex(b => b.id === busId);
          if (busIndex !== -1) {
            buses.splice(busIndex, 1);
            resolve({
              success: true,
              message: 'Bus deleted successfully'
            });
          } else {
            resolve({
              success: false,
              error: 'Bus not found'
            });
          }
        }
      }, 500);
    });
  }

  // Admin: Get search analytics
  async getSearchAnalytics() {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (appState && appState.searchLogs) {
          const logs = appState.searchLogs;
          
          // Process logs into analytics
          const successful = logs.filter(log => log.status === 'success');
          const failed = logs.filter(log => log.status === 'failed');
          const repeated = logs.filter(log => log.isRepeated);
          
          // Generate daily data for charts
          const dailyData = [];
          const last7Days = Array.from({ length: 7 }, (_, i) => {
            const date = new Date();
            date.setDate(date.getDate() - i);
            return date.toISOString().split('T')[0];
          }).reverse();
          
          last7Days.forEach(date => {
            const dayLogs = logs.filter(log => {
              const logDate = new Date(log.timestamp).toISOString().split('T')[0];
              return logDate === date;
            });
            
            dailyData.push({
              date,
              successful: dayLogs.filter(log => log.status === 'success').length,
              failed: dayLogs.filter(log => log.status === 'failed').length,
              repeated: dayLogs.filter(log => log.isRepeated).length
            });
          });

          resolve({
            success: true,
            data: {
              successfulSearches: successful,
              failedSearches: failed,
              repeatedSearches: repeated,
              dailyData
            }
          });
        } else {
          // Mock data fallback
          resolve({
            success: true,
            data: {
              successfulSearches: [],
              failedSearches: [],
              repeatedSearches: [],
              dailyData: []
            }
          });
        }
      }, 500);
    });
  }
}

// Export singleton instance
export default new ApiService();