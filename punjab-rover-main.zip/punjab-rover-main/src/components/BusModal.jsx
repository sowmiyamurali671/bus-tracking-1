import { useState, useEffect, useRef } from 'react';
import { X, Clock, MapPin, Wifi, Gauge, Calendar } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import wsService from '../services/ws';
import { useAppState } from '../context/AppContext';

// Fix for default markers in react-leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom bus icon
const busIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,' + btoa(`
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="8" width="24" height="16" rx="2" fill="#0B5FFF"/>
      <rect x="6" y="10" width="4" height="3" rx="1" fill="white"/>
      <rect x="14" y="10" width="4" height="3" rx="1" fill="white"/>
      <rect x="22" y="10" width="4" height="3" rx="1" fill="white"/>
      <circle cx="10" cy="26" r="2" fill="#333"/>
      <circle cx="22" cy="26" r="2" fill="#333"/>
      <rect x="4" y="24" width="24" height="2" fill="#0B5FFF"/>
    </svg>
  `),
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32]
});

// Custom passenger icon
const passengerIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,' + btoa(`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="10" fill="#009688"/>
      <circle cx="12" cy="9" r="3" fill="white"/>
      <path d="M6 20c0-4 2.7-6 6-6s6 2 6 6" fill="white"/>
    </svg>
  `),
  iconSize: [24, 24],
  iconAnchor: [12, 24],
  popupAnchor: [0, -24]
});

const BusModal = ({ bus, passengerLocation, isOpen, onClose }) => {
  const { state } = useAppState();
  const [busData, setBusData] = useState(bus);
  const mapRef = useRef(null);

  // Update bus data when state changes
  useEffect(() => {
    if (bus && state.buses) {
      const updatedBus = state.buses.find(b => b.id === bus.id);
      if (updatedBus) {
        setBusData(updatedBus);
      }
    }
  }, [bus?.id, state.buses, state.lastUpdated]);

  useEffect(() => {
    if (!isOpen || !bus) return;

    // Subscribe to real-time updates for this bus
    const unsubscribe = wsService.subscribeToBus(bus.id, (update) => {
      setBusData(prevData => ({
        ...prevData,
        currentLocation: update.location || prevData.currentLocation,
        speed: update.speed || prevData.speed,
        nextStop: update.nextStop || prevData.nextStop,
        eta: update.eta || prevData.eta,
        lastSeen: new Date().toISOString()
      }));
    });

    return () => {
      unsubscribe();
    };
  }, [isOpen, bus?.id]);

  useEffect(() => {
    // Invalidate map size when modal opens
    if (isOpen && mapRef.current) {
      setTimeout(() => {
        mapRef.current.invalidateSize();
      }, 100);
    }
  }, [isOpen]);

  if (!isOpen || !bus || !busData) return null;

  // Create polyline coordinates from stops
  const polylinePositions = busData.stops?.map(stop => [stop.lat, stop.lng]) || [];

  // Calculate map bounds to include bus and passenger
  const allPositions = [
    [busData.currentLocation?.lat || 0, busData.currentLocation?.lng || 0],
    ...polylinePositions
  ];
  
  if (passengerLocation) {
    allPositions.push([passengerLocation.lat, passengerLocation.lng]);
  }

  const bounds = L.latLngBounds(allPositions);

  const formatLastSeen = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min ago`;
    return date.toLocaleTimeString();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50 backdrop-blur-sm animate-fade-in">
      <div className="bg-card rounded-2xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden animate-scale-in">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-border">
          <div>
            <h2 className="text-2xl font-bold text-foreground">
              {busData.busNo}
            </h2>
            <p className="text-muted-foreground">{busData.route}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-muted transition-colors duration-200"
          >
            <X className="h-6 w-6 text-muted-foreground" />
          </button>
        </div>

        <div className="flex flex-col lg:flex-row h-[70vh]">
          {/* Map Section */}
          <div className="flex-1 relative">
            <MapContainer
              ref={mapRef}
              bounds={bounds}
              className="h-full w-full"
              scrollWheelZoom={true}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              
              {/* Bus Marker */}
              <Marker
                position={[busData.currentLocation.lat, busData.currentLocation.lng]}
                icon={busIcon}
              >
                <Popup>
                  <div className="text-sm">
                    <strong>{busData.busNo}</strong><br />
                    Speed: {busData.speed} km/h<br />
                    Next: {busData.nextStop}
                  </div>
                </Popup>
              </Marker>

              {/* Passenger Marker */}
              {passengerLocation && (
                <Marker
                  position={[passengerLocation.lat, passengerLocation.lng]}
                  icon={passengerIcon}
                >
                  <Popup>
                    <div className="text-sm">
                      <strong>Your Location</strong>
                    </div>
                  </Popup>
                </Marker>
              )}

              {/* Route Polyline */}
              <Polyline
                positions={polylinePositions}
                color="#0B5FFF"
                weight={4}
                opacity={0.7}
                dashArray="10, 10"
              />

              {/* Stop Markers */}
              {busData.stops?.map((stop, index) => (
                <Marker
                  key={index}
                  position={[stop.lat, stop.lng]}
                >
                  <Popup>
                    <div className="text-sm">
                      <strong>{stop.name}</strong><br />
                      ETA: {stop.eta}
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>

          {/* Details Panel */}
          <div className="lg:w-80 p-6 border-t lg:border-t-0 lg:border-l border-border overflow-y-auto">
            <h3 className="text-lg font-semibold mb-4 text-foreground">
              Live Bus Details
            </h3>

            <div className="space-y-4">
              {/* Current Status */}
              <div className="p-3 bg-muted rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Gauge className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">Current Speed</span>
                </div>
                <p className="text-lg font-bold text-foreground">
                  {busData.speed} km/h
                </p>
              </div>

              {/* Next Stop */}
              <div className="p-3 bg-muted rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <MapPin className="h-4 w-4 text-accent" />
                  <span className="text-sm font-medium">Next Stop</span>
                </div>
                <p className="font-semibold text-foreground">
                  {busData.nextStop}
                </p>
              </div>

              {/* ETA */}
              <div className="p-3 bg-muted rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Clock className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">ETA</span>
                </div>
                <p className="text-lg font-bold text-foreground">
                  {busData.eta}
                </p>
              </div>

              {/* Device Status */}
              {busData.deviceMac && (
                <div className="p-3 bg-muted rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Wifi className="h-4 w-4 text-success" />
                    <span className="text-sm font-medium">Device</span>
                  </div>
                  <p className="text-xs font-mono text-muted-foreground">
                    {busData.deviceMac}
                  </p>
                </div>
              )}

              {/* Last Seen */}
              <div className="p-3 bg-muted rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Last Seen</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {formatLastSeen(busData.lastSeen)}
                </p>
              </div>

              {/* Availability Status */}
              <div className={`p-3 rounded-lg ${
                busData.isAvailable 
                  ? 'bg-success-light' 
                  : 'bg-destructive-light'
              }`}>
                <p className={`text-sm font-semibold ${
                  busData.isAvailable 
                    ? 'text-success-light-foreground' 
                    : 'text-destructive-light-foreground'
                }`}>
                  {busData.isAvailable ? '✅ Available for Passengers' : '❌ Not Available'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BusModal;