import { Clock, MapPin, Wifi, WifiOff } from 'lucide-react';

const BusCard = ({ bus, onCardClick }) => {
  const handleClick = () => {
    onCardClick(bus);
  };

  const getBadgeStyle = () => {
    if (bus.isAvailable) {
      return "bg-success-light text-success-light-foreground";
    }
    return "bg-destructive-light text-destructive-light-foreground";
  };

  const getDeviceStatus = () => {
    return bus.deviceMac ? (
      <div className="flex items-center space-x-1 text-xs text-success">
        <Wifi className="h-3 w-3" />
        <span>Connected</span>
      </div>
    ) : (
      <div className="flex items-center space-x-1 text-xs text-muted-foreground">
        <WifiOff className="h-3 w-3" />
        <span>No Device</span>
      </div>
    );
  };

  return (
    <div 
      onClick={handleClick}
      className="bg-card rounded-xl shadow-lg p-4 flex flex-col justify-between cursor-pointer transition-all duration-200 hover:shadow-xl hover:scale-105 border border-border animate-fade-in"
    >
      {/* Header with Bus Number and Availability */}
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="text-lg font-bold text-foreground mb-1">
            {bus.busNo}
          </h3>
          <p className="text-sm text-muted-foreground">
            {bus.route}
          </p>
        </div>
        <div className="flex flex-col items-end space-y-2">
          <span className={`inline-block px-2 py-1 rounded-full text-xs font-semibold ${getBadgeStyle()}`}>
            {bus.isAvailable ? 'AVAILABLE' : 'UNAVAILABLE'}
          </span>
          {getDeviceStatus()}
        </div>
      </div>

      {/* Bus Information */}
      <div className="space-y-2 mb-4">
        <div className="flex items-center space-x-2 text-sm">
          <Clock className="h-4 w-4 text-primary" />
          <span className="text-muted-foreground">ETA:</span>
          <span className="font-medium text-foreground">
            {bus.etaToPassenger || bus.eta}
          </span>
        </div>
        
        <div className="flex items-center space-x-2 text-sm">
          <MapPin className="h-4 w-4 text-accent" />
          <span className="text-muted-foreground">Last Stop:</span>
          <span className="font-medium text-foreground">
            {bus.lastStopCrossed || 'Starting point'}
          </span>
        </div>

        {bus.speed > 0 && (
          <div className="text-xs text-muted-foreground">
            Current Speed: {bus.speed} km/h
          </div>
        )}
      </div>

      {/* Action Prompt */}
      <div className="pt-2 border-t border-border">
        <p className="text-xs text-primary font-medium text-center">
          Click to view on map →
        </p>
      </div>
    </div>
  );
};

export default BusCard;