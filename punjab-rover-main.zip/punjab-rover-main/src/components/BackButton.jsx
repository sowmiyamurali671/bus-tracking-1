import { ArrowLeft } from 'lucide-react';

const BackButton = () => {
  const handleBack = () => {
    window.history.back();
  };

  return (
    <button
      onClick={handleBack}
      className="fixed top-4 left-4 z-50 flex items-center space-x-2 bg-slate-100 hover:bg-slate-200 px-3 py-1 rounded-lg transition-colors duration-200 shadow-sm"
    >
      <ArrowLeft className="h-4 w-4" />
      <span className="text-sm font-medium">Back</span>
    </button>
  );
};

export default BackButton;