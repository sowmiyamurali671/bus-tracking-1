import { useState } from 'react';
import { Edit, Trash2, User, Bus } from 'lucide-react';

const DriverList = ({ drivers, onEdit, onDelete, buses, isLoading }) => {
  const [editingDriver, setEditingDriver] = useState(null);
  const [editForm, setEditForm] = useState({});

  const getBusForDriver = (driverId) => {
    return buses.find(bus => bus.driver === driverId);
  };

  const handleEditClick = (driver) => {
    setEditingDriver(driver.id);
    setEditForm({
      name: driver.name,
      username: driver.username,
      password: driver.password,
      assignedBusNumber: driver.assignedBusNumber || ''
    });
  };

  const handleSaveEdit = async () => {
    await onEdit(editingDriver, editForm);
    setEditingDriver(null);
    setEditForm({});
  };

  const handleCancelEdit = () => {
    setEditingDriver(null);
    setEditForm({});
  };

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent mx-auto"></div>
        <p className="mt-2 text-muted-foreground">Loading drivers...</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl shadow-lg border border-border">
      <div className="p-6 border-b border-border">
        <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
          <User className="h-5 w-5" />
          All Drivers
        </h2>
      </div>
      <div className="p-6">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Driver Name</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Driver ID</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Username</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Assigned Bus Number</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Status</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {drivers.map((driver) => {
                const assignedBus = getBusForDriver(driver.id);
                const isEditing = editingDriver === driver.id;

                return (
                  <tr key={driver.id} className="border-b border-border hover:bg-muted odd:bg-slate-50 transition-colors">
                    <td className="py-3 px-4">
                      {isEditing ? (
                        <input
                          type="text"
                          value={editForm.name}
                          onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                          className="w-full px-2 py-1 border border-input rounded bg-background text-sm"
                        />
                      ) : (
                        <span className="font-medium text-foreground">{driver.name}</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-muted-foreground">{driver.driverId}</td>
                    <td className="py-3 px-4">
                      {isEditing ? (
                        <input
                          type="text"
                          value={editForm.username}
                          onChange={(e) => setEditForm(prev => ({ ...prev, username: e.target.value }))}
                          className="w-full px-2 py-1 border border-input rounded bg-background text-sm"
                        />
                      ) : (
                        <span className="text-muted-foreground">{driver.username}</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {isEditing ? (
                        <input
                          type="text"
                          value={editForm.assignedBusNumber}
                          onChange={(e) => setEditForm(prev => ({ ...prev, assignedBusNumber: e.target.value }))}
                          placeholder="e.g., 5A"
                          className="w-full px-2 py-1 border border-input rounded bg-background text-sm"
                        />
                      ) : (
                        driver.assignedBusNumber ? (
                          <div className="flex items-center space-x-1 text-success">
                            <Bus className="h-3 w-3" />
                            <span className="text-xs font-semibold">{driver.assignedBusNumber}</span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-xs">Unassigned</span>
                        )
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        driver.isActive 
                          ? 'bg-success-light text-success-light-foreground' 
                          : 'bg-destructive-light text-destructive-light-foreground'
                      }`}>
                        {driver.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {isEditing ? (
                        <div className="flex space-x-2">
                          <button
                            onClick={handleSaveEdit}
                            className="px-2 py-1 bg-success text-success-foreground rounded text-xs font-medium hover:bg-opacity-80 transition-colors"
                          >
                            Save
                          </button>
                          <button
                            onClick={handleCancelEdit}
                            className="px-2 py-1 bg-muted text-muted-foreground rounded text-xs font-medium hover:bg-opacity-80 transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleEditClick(driver)}
                            className="px-2 py-1 bg-primary text-primary-foreground rounded text-xs font-medium hover:bg-opacity-80 transition-colors flex items-center gap-1"
                          >
                            <Edit className="h-3 w-3" />
                            Edit
                          </button>
                          <button
                            onClick={() => onDelete(driver.id)}
                            className="px-2 py-1 bg-destructive text-destructive-foreground rounded text-xs font-medium hover:bg-opacity-80 transition-colors flex items-center gap-1"
                          >
                            <Trash2 className="h-3 w-3" />
                            Delete
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          
          {drivers.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <User className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No drivers found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DriverList;