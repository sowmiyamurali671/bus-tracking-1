import { useState, useEffect } from 'react';
import { LogOut, Search, MapPin, Wifi, WifiOff, Clock, Gauge } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import apiService, { setAppContext } from '../services/api';
import wsService from '../services/ws';
import BackButton from './BackButton';
import { useAppState } from '../context/AppContext';
import useGeolocation from '../hooks/useGeolocation';

const DriverDashboard = ({ driver, onLogout }) => {
  const { state, actions } = useAppState();
  const { location, error: geoError, isTracking, startWatching, stopWatching, getCurrentPosition } = useGeolocation();
  const [searchBusNo, setSearchBusNo] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [connectedBus, setConnectedBus] = useState(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Set context for api service
    setAppContext(actions, state);
    
    // Connect to WebSocket when component mounts
    wsService.connect();

    // Check if driver is already connected to a bus
    const currentBus = state.buses.find(bus => bus.driver === driver.id);
    if (currentBus) {
      setConnectedBus(currentBus);
    }

    return () => {
      // Cleanup location tracking on unmount
      stopWatching();
    };
  }, [actions, state, driver.id]);

  // Update connected bus when state changes
  useEffect(() => {
    const currentBus = state.buses.find(bus => bus.driver === driver.id);
    setConnectedBus(currentBus || null);
  }, [state.buses, driver.id]);

  // Handle geolocation updates for connected bus
  useEffect(() => {
    if (connectedBus && location && isTracking) {
      // Calculate speed (simple approach)
      const speed = location.speed ? Math.round(location.speed * 3.6) : 0; // Convert m/s to km/h
      
      // Update bus location via actions
      actions.updateBusLocation(connectedBus.id, location.lat, location.lng, speed);
      
      // Emit location update via WebSocket (mock)
      wsService.send({
        type: 'driver_location_update',
        busId: connectedBus.id,
        location: { lat: location.lat, lng: location.lng },
        speed,
        timestamp: location.timestamp,
        driverId: driver.id
      });
    }
  }, [location, connectedBus, isTracking, actions, driver.id]);

  const handleSearch = async () => {
    if (!searchBusNo.trim()) return;

    setError(null);
    try {
      // Search buses by registration number
      const response = await apiService.searchBusByRegistration(searchBusNo);
      if (response.success) {
        setSearchResults(response.data);
      } else {
        setError(response.error || 'No buses found');
        setSearchResults([]);
      }
    } catch (err) {
      setError('Failed to search buses');
      setSearchResults([]);
    }
  };

  const handleConnectToBus = async (bus) => {
    if (connectedBus) {
      setError('You are already connected to a bus. Disconnect first.');
      return;
    }

    setIsConnecting(true);
    setError(null);

    try {
      // Get current GPS location first
      const location = await getCurrentPosition();
      
      // Connect to bus via actions
      actions.connectDriverToBus(bus.id, driver.id);
      
      // Update bus location immediately
      actions.updateBusLocation(bus.id, location.lat, location.lng, 0);
      
      // Start GPS tracking
      startWatching({
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 30000
      });
      
      setSearchResults([]);
      setSearchBusNo('');
      
    } catch (err) {
      setError(err.message || 'Please enable GPS to connect to bus');
    } finally {
      setIsConnecting(false);
    }
  };

  // These functions are now handled by useGeolocation hook and useEffect above

  const handleDisconnect = () => {
    if (connectedBus) {
      actions.disconnectDriverFromBus(connectedBus.id, driver.id);
    }
    stopWatching();
    setError(null);
  };

  const handleLogout = () => {
    if (connectedBus) {
      actions.disconnectDriverFromBus(connectedBus.id, driver.id);
    }
    stopWatching();
    onLogout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      <BackButton />
      {/* Header */}
      <div className="bg-card shadow-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-xl font-bold text-primary">Driver Dashboard</h1>
              <p className="text-sm text-muted-foreground">Welcome, {driver.name}</p>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center space-x-2 px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-opacity-80 transition-colors duration-200"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6">
        {/* Connection Status */}
        {connectedBus ? (
          <div className="bg-success-light border border-success rounded-xl p-6 mb-6">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-lg font-semibold text-success-light-foreground mb-2">
                  Connected to {connectedBus.busNo}
                </h2>
                <p className="text-sm text-success-light-foreground mb-4">
                  Route: {connectedBus.route}
                </p>
                
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center space-x-1">
                    {isTracking ? (
                      <>
                        <Wifi className="h-4 w-4 text-success" />
                        <span className="text-success-light-foreground">Location Tracking Active</span>
                      </>
                    ) : (
                      <>
                        <WifiOff className="h-4 w-4 text-destructive" />
                        <span className="text-destructive">Location Tracking Inactive</span>
                      </>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span className="text-success-light-foreground">
                      Next: {connectedBus.nextStop}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleDisconnect}
                className="bg-destructive text-destructive-foreground px-4 py-2 rounded-lg hover:bg-opacity-80 transition-colors duration-200"
              >
                Disconnect
              </button>
            </div>
          </div>
        ) : (
          /* Bus Search */
          <div className="bg-card rounded-xl shadow-lg p-6 border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-4">
              Connect to Bus
            </h2>
            
            <div className="flex space-x-4 mb-6">
              <div className="flex-1">
                <input
                  type="text"
                  value={searchBusNo}
                  onChange={(e) => setSearchBusNo(e.target.value)}
                  placeholder="Enter bus registration number (e.g., PB 65-BB4490)"
                  className="w-full px-4 py-3 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />
              </div>
              <button
                onClick={handleSearch}
                disabled={!searchBusNo.trim()}
                className="bg-gradient-to-r from-primary to-primary-hover text-primary-foreground px-6 py-3 rounded-lg font-medium shadow-md transition-all duration-200 hover:shadow-lg hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center space-x-2"
              >
                <Search className="h-4 w-4" />
                <span>Search</span>
              </button>
            </div>

            {/* Search Results */}
            {searchResults.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-lg font-medium text-foreground">Available Buses</h3>
                {searchResults.map((bus) => (
                  <div key={bus.id} className="flex justify-between items-center p-4 bg-muted rounded-lg">
                    <div>
                      <h4 className="font-semibold text-foreground">Bus {bus.busNo} ({bus.registrationNo})</h4>
                      <p className="text-sm text-muted-foreground">{bus.route}</p>
                      <div className="flex items-center space-x-4 mt-1 text-xs">
                        <span className={`px-2 py-1 rounded-full ${
                          bus.isAvailable 
                            ? 'bg-success-light text-success-light-foreground' 
                            : 'bg-destructive-light text-destructive-light-foreground'
                        }`}>
                          {bus.isAvailable ? 'Available' : 'Unavailable'}
                        </span>
                        {bus.driver && (
                          <span className="text-muted-foreground">
                            Driver: {bus.driver}
                          </span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => handleConnectToBus(bus)}
                      disabled={isConnecting || !bus.isAvailable || bus.driver}
                      className="bg-gradient-to-r from-accent to-accent-hover text-accent-foreground px-4 py-2 rounded-lg font-medium shadow-md transition-all duration-200 hover:shadow-lg hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                    >
                      {isConnecting ? 'Connecting...' : 'Connect'}
                    </button>
                  </div>
                ))}
              </div>
            )}

            {searchResults.length === 0 && searchBusNo && (
              <p className="text-muted-foreground text-center py-4">
                No buses found matching "{searchBusNo}"
              </p>
            )}
          </div>
        )}

        {/* Error Message */}
        {(error || geoError) && (
          <div className="mt-4 p-4 bg-destructive-light text-destructive-light-foreground rounded-lg">
            {error || geoError?.message}
          </div>
        )}

        {/* Instructions */}
        <div className="mt-6 bg-muted rounded-lg p-4">
          <h3 className="font-medium text-foreground mb-2">Instructions:</h3>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Search for your assigned bus using the registration number</li>
            <li>• Click "Connect" to start tracking your location</li>
            <li>• Your location will be shared with passengers automatically</li>
            <li>• Remember to disconnect when your shift ends</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DriverDashboard;