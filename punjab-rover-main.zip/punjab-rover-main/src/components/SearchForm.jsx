import { useState } from 'react';
import { Search, ArrowRight } from 'lucide-react';
import LocationButton from './LocationButton';

const SearchForm = ({ onSearch, isLoading = false }) => {
  const [fromLocation, setFromLocation] = useState('');
  const [toLocation, setToLocation] = useState('');
  const [fromCoords, setFromCoords] = useState(null);

  const handleLocationDetected = (locationData) => {
    setFromLocation(locationData.address);
    setFromCoords({ lat: locationData.lat, lng: locationData.lng });
  };

  const handleSearch = (e) => {
    e.preventDefault();
    
    if (!toLocation.trim()) {
      alert('Please enter a destination');
      return;
    }

    // Default coordinates if location not detected (Chandigarh center)
    const searchCoords = fromCoords || { lat: 30.7333, lng: 76.7794 };
    
    onSearch({
      fromLat: searchCoords.lat,
      fromLng: searchCoords.lng,
      fromLocation: fromLocation || 'Current Location',
      toLocation: toLocation.trim()
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6">
      <div className="bg-card rounded-2xl shadow-xl p-6 border border-border">
        <h2 className="text-2xl font-bold text-center mb-6 text-foreground">
          Find Your Bus
        </h2>
        
        <form onSubmit={handleSearch} className="space-y-4 md:space-y-0 md:flex md:items-end md:space-x-4">
          {/* From Location Input */}
          <div className="flex-1">
            <label htmlFor="from" className="block text-sm font-medium text-muted-foreground mb-2">
              From
            </label>
            <div className="relative">
              <input
                id="from"
                type="text"
                value={fromLocation}
                onChange={(e) => setFromLocation(e.target.value)}
                placeholder="Enter pickup location"
                className="w-full rounded-lg bg-background px-4 py-3 pr-12 shadow-sm border border-input focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
              />
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                <LocationButton 
                  onLocationDetected={handleLocationDetected}
                  className="hover:bg-muted rounded-full"
                />
              </div>
            </div>
          </div>

          {/* Arrow Icon (hidden on mobile) */}
          <div className="hidden md:block">
            <ArrowRight className="h-6 w-6 text-muted-foreground mb-3" />
          </div>

          {/* To Location Input */}
          <div className="flex-1">
            <label htmlFor="to" className="block text-sm font-medium text-muted-foreground mb-2">
              To (Destination)
            </label>
            <input
              id="to"
              type="text"
              value={toLocation}
              onChange={(e) => setToLocation(e.target.value)}
              placeholder="Enter destination"
              className="w-full rounded-lg bg-background px-4 py-3 shadow-sm border border-input focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
              required
            />
          </div>

          {/* Search Button */}
          <div className="md:flex-shrink-0">
            <button
              type="submit"
              disabled={isLoading || !toLocation.trim()}
              className="w-full md:w-auto bg-gradient-to-r from-primary to-primary-hover text-primary-foreground px-8 py-3 rounded-lg font-medium shadow-md transition-all duration-200 hover:shadow-lg hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-primary-foreground border-t-transparent"></div>
                  <span>Searching...</span>
                </>
              ) : (
                <>
                  <Search className="h-4 w-4" />
                  <span>Search Buses</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Search Tips */}
        <div className="mt-4 text-xs text-muted-foreground text-center">
          <p>💡 Click the location icon to auto-detect your current position</p>
        </div>
      </div>
    </div>
  );
};

export default SearchForm;