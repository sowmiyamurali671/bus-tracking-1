import { useState } from 'react';
import { MapPin, Loader2 } from 'lucide-react';

const LocationButton = ({ onLocationDetected, className = "" }) => {
  const [isDetecting, setIsDetecting] = useState(false);
  const [error, setError] = useState(null);

  const detectLocation = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by this browser');
      return;
    }

    setIsDetecting(true);
    setError(null);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;
          
          // Try to get address from coordinates (mock implementation)
          // TODO: Replace with actual reverse geocoding service
          const mockAddress = await getMockAddressFromCoords(latitude, longitude);
          
          onLocationDetected({
            lat: latitude,
            lng: longitude,
            address: mockAddress
          });
          
          setIsDetecting(false);
        } catch (err) {
          setError('Failed to get address for location');
          setIsDetecting(false);
        }
      },
      (error) => {
        let errorMessage = 'Failed to get location';
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'Location access denied by user';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Location information is unavailable';
            break;
          case error.TIMEOUT:
            errorMessage = 'Location request timed out';
            break;
          default:
            errorMessage = 'An unknown error occurred';
            break;
        }
        
        setError(errorMessage);
        setIsDetecting(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes cache
      }
    );
  };

  // Mock function to simulate reverse geocoding
  // TODO: Replace with actual geocoding service like Google Maps or Mapbox
  const getMockAddressFromCoords = async (lat, lng) => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Simple mock address based on coordinates
    const punjabCities = [
      'Chandigarh', 'Amritsar', 'Ludhiana', 'Patiala', 'Jalandhar', 
      'Bathinda', 'Mohali', 'Ferozepur', 'Moga', 'Sangrur'
    ];
    
    const randomCity = punjabCities[Math.floor(Math.random() * punjabCities.length)];
    return `Near ${randomCity}, Punjab`;
  };

  return (
    <div className="relative">
      <button
        onClick={detectLocation}
        disabled={isDetecting}
        className={`p-2 rounded-full transition-all duration-200 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-primary ${
          isDetecting 
            ? 'text-muted-foreground animate-pulse-location' 
            : 'text-primary hover:text-primary-hover'
        } ${className}`}
        title={isDetecting ? "Detecting location..." : "Use my current location"}
      >
        {isDetecting ? (
          <Loader2 className="h-5 w-5 animate-spin" />
        ) : (
          <MapPin className="h-5 w-5" />
        )}
      </button>
      
      {error && (
        <div className="absolute top-full left-0 mt-1 p-2 bg-destructive-light text-destructive-light-foreground text-xs rounded-lg shadow-lg max-w-48 z-10">
          {error}
        </div>
      )}
    </div>
  );
};

export default LocationButton;