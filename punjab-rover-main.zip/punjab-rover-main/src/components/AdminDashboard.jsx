import { useState, useEffect } from 'react';
import { LogOut, Plus, Users, Bus, Settings, MapPin, Wifi, WifiOff, BarChart3, Eye, Search, Edit, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import apiService, { setAppContext } from '../services/api';
import DriverList from './DriverList';
import Analytics from './Analytics';
import BackButton from './BackButton';
import { validateBusNumber, validateRegistrationNumber, getBusNumberError, getRegistrationNumberError } from '../utils/validation';
import { useAppState } from '../context/AppContext';

const AdminDashboard = ({ admin, onLogout }) => {
  const { state, actions } = useAppState();
  const [activeTab, setActiveTab] = useState('buses');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [validationErrors, setValidationErrors] = useState({});

  // Use state from context
  const buses = state.buses || [];
  const drivers = state.drivers || [];
  
  // Form states
  const [newDriver, setNewDriver] = useState({
    name: '',
    driverId: '',
    username: '',
    password: '',
    phone: '',
    experience: '',
    assignedBusNumber: ''
  });
  
  const [newBus, setNewBus] = useState({
    busNo: '',
    registrationNo: '',
    route: '',
    stops: [{ name: '', lat: '', lng: '', eta: '0 min' }],
    deviceMac: ''
  });

  const [busSearchQuery, setBusSearchQuery] = useState('');
  const [editingBus, setEditingBus] = useState(null);
  const [editBusForm, setEditBusForm] = useState({});
  
  const navigate = useNavigate();

  useEffect(() => {
    // Set context for api service
    setAppContext(actions, state);
  }, [actions, state]);

  const handleAddDriver = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await apiService.addDriver(newDriver);
      if (response.success) {
        setSuccess('Driver added successfully');
        setNewDriver({
          name: '',
          driverId: '',
          username: '',
          password: '',
          phone: '',
          experience: '',
          assignedBusNumber: ''
        });
        loadData();
      } else {
        setError(response.error || 'Failed to add driver');
      }
    } catch (err) {
      setError('Failed to add driver');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddBus = async (e) => {
    e.preventDefault();
    setError(null);
    setValidationErrors({});
    
    // Validate bus number and registration
    const busNoError = getBusNumberError(newBus.busNo);
    const regNoError = getRegistrationNumberError(newBus.registrationNo);
    
    if (busNoError || regNoError) {
      setValidationErrors({
        busNo: busNoError,
        registrationNo: regNoError
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      const response = await apiService.addBus(newBus);
      if (response.success) {
        setSuccess('Bus added successfully');
        setNewBus({
          busNo: '',
          registrationNo: '',
          route: '',
          stops: [{ name: '', lat: '', lng: '', eta: '0 min' }],
          deviceMac: ''
        });
        setValidationErrors({});
        loadData();
      } else {
        setError(response.error || 'Failed to add bus');
      }
    } catch (err) {
      setError('Failed to add bus');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleBusAvailability = async (busId, currentStatus) => {
    try {
      const response = await apiService.updateBusAvailability(busId, !currentStatus);
      if (response.success) {
        setSuccess(response.message);
        loadData();
      } else {
        setError(response.error || 'Failed to update bus status');
      }
    } catch (err) {
      setError('Failed to update bus status');
    }
  };

  const assignDevice = async (busId) => {
    const deviceMac = prompt('Enter device MAC address:');
    if (!deviceMac) return;
    
    try {
      const response = await apiService.assignDeviceToBus(busId, deviceMac);
      if (response.success) {
        setSuccess(response.message);
        loadData();
      } else {
        setError(response.error || 'Failed to assign device');
      }
    } catch (err) {
      setError('Failed to assign device');
    }
  };

  const addBusStop = () => {
    setNewBus(prev => ({
      ...prev,
      stops: [...prev.stops, { name: '', lat: '', lng: '', eta: '0 min' }]
    }));
  };

  const updateBusStop = (index, field, value) => {
    setNewBus(prev => ({
      ...prev,
      stops: prev.stops.map((stop, i) => 
        i === index ? { ...stop, [field]: value } : stop
      )
    }));
  };

  const removeBusStop = (index) => {
    setNewBus(prev => ({
      ...prev,
      stops: prev.stops.filter((_, i) => i !== index)
    }));
  };

  const handleEditDriver = async (driverId, driverData) => {
    try {
      const response = await apiService.updateDriver(driverId, driverData);
      if (response.success) {
        setSuccess(response.message);
        loadData();
      } else {
        setError(response.error || 'Failed to update driver');
      }
    } catch (err) {
      setError('Failed to update driver');
    }
  };

  const handleDeleteDriver = async (driverId) => {
    if (!confirm('Are you sure you want to delete this driver?')) return;
    
    try {
      const response = await apiService.deleteDriver(driverId);
      if (response.success) {
        setSuccess(response.message);
        loadData();
      } else {
        setError(response.error || 'Failed to delete driver');
      }
    } catch (err) {
      setError('Failed to delete driver');
    }
  };

  const handleEditBus = async (busId, busData) => {
    // Validate bus data before saving
    const busNoError = getBusNumberError(busData.busNo);
    const regNoError = getRegistrationNumberError(busData.registrationNo);
    
    if (busNoError || regNoError) {
      setError(`Validation failed: ${busNoError || regNoError}`);
      return;
    }
    
    try {
      const response = await apiService.editBus(busId, busData);
      if (response.success) {
        setSuccess(response.message);
        loadData();
        setEditingBus(null);
        setEditBusForm({});
      } else {
        setError(response.error || 'Failed to update bus');
      }
    } catch (err) {
      setError('Failed to update bus');
    }
  };

  const handleDeleteBus = async (busId) => {
    if (!confirm('Are you sure you want to delete this bus?')) return;
    
    try {
      const response = await apiService.deleteBus(busId);
      if (response.success) {
        setSuccess(response.message);
        loadData();
      } else {
        setError(response.error || 'Failed to delete bus');
      }
    } catch (err) {
      setError('Failed to delete bus');
    }
  };

  const filteredBuses = buses.filter(bus => 
    bus.busNo.toLowerCase().includes(busSearchQuery.toLowerCase()) ||
    (bus.registrationNo && bus.registrationNo.toLowerCase().includes(busSearchQuery.toLowerCase()))
  );

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  const clearMessages = () => {
    setError(null);
    setSuccess(null);
    setValidationErrors({});
  };

  return (
    <div className="min-h-screen bg-background">
      <BackButton />
      {/* Header */}
      <div className="bg-card shadow-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-xl font-bold text-primary">Admin Dashboard</h1>
              <p className="text-sm text-muted-foreground">Welcome, {admin.name}</p>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center space-x-2 px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-opacity-80 transition-colors duration-200"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Tabs */}
        <div className="flex flex-wrap gap-1 bg-muted p-1 rounded-lg mb-6">
          {[
            { id: 'buses', label: 'View Buses', icon: Bus },
            { id: 'addBus', label: 'Add Bus', icon: Plus },
            { id: 'addDriver', label: 'Add Driver', icon: Users },
            { id: 'viewDrivers', label: 'View Drivers', icon: Eye },
            { id: 'analytics', label: 'Analytics', icon: BarChart3 }
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => {
                setActiveTab(id);
                clearMessages();
              }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md font-medium transition-all duration-200 ${
                activeTab === id
                  ? 'bg-card text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{label}</span>
            </button>
          ))}
        </div>

        {/* Messages */}
        {error && (
          <div className="mb-6 p-4 bg-destructive-light text-destructive-light-foreground rounded-lg">
            {error}
          </div>
        )}
        
        {success && (
          <div className="mb-6 p-4 bg-success-light text-success-light-foreground rounded-lg">
            {success}
          </div>
        )}

        {/* Tab Content */}
        {activeTab === 'buses' && (
          <div className="bg-card rounded-xl shadow-lg border border-border">
            <div className="p-6 border-b border-border">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-foreground">All Buses</h2>
                <div className="flex items-center space-x-2">
                  <Search className="h-4 w-4 text-muted-foreground" />
                  <input
                    type="text"
                    value={busSearchQuery}
                    onChange={(e) => setBusSearchQuery(e.target.value)}
                    placeholder="Search by bus number or registration..."
                    className="px-3 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary text-sm"
                  />
                </div>
              </div>
            </div>
            <div className="p-6">
              {isLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent mx-auto"></div>
                  <p className="mt-2 text-muted-foreground">Loading buses...</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Bus Number</th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Registration</th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Route</th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Device</th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Availability</th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredBuses.map((bus) => {
                        const isEditing = editingBus === bus.id;
                        return (
                        <tr key={bus.id} className="border-b border-border hover:bg-muted odd:bg-slate-50 transition-colors">
                          <td className="py-3 px-4">
                            {isEditing ? (
                              <input
                                type="text"
                                value={editBusForm.busNo || ''}
                                onChange={(e) => setEditBusForm(prev => ({ ...prev, busNo: e.target.value }))}
                                className="w-full px-2 py-1 border border-input rounded bg-background text-sm"
                              />
                            ) : (
                              <span className="font-medium text-foreground">{bus.busNo}</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {isEditing ? (
                              <input
                                type="text"
                                value={editBusForm.registrationNo || ''}
                                onChange={(e) => setEditBusForm(prev => ({ ...prev, registrationNo: e.target.value }))}
                                className="w-full px-2 py-1 border border-input rounded bg-background text-sm"
                              />
                            ) : (
                              <span className="text-muted-foreground">{bus.registrationNo || 'N/A'}</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {isEditing ? (
                              <input
                                type="text"
                                value={editBusForm.route || ''}
                                onChange={(e) => setEditBusForm(prev => ({ ...prev, route: e.target.value }))}
                                className="w-full px-2 py-1 border border-input rounded bg-background text-sm"
                              />
                            ) : (
                              <span className="text-muted-foreground">{bus.route}</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {isEditing ? (
                              <input
                                type="text"
                                value={editBusForm.deviceMac || ''}
                                onChange={(e) => setEditBusForm(prev => ({ ...prev, deviceMac: e.target.value }))}
                                placeholder="MAC Address"
                                className="w-full px-2 py-1 border border-input rounded bg-background text-sm"
                              />
                            ) : (
                              bus.deviceMac ? (
                                <div className="flex items-center space-x-1 text-success">
                                  <Wifi className="h-3 w-3" />
                                  <span className="text-xs font-mono">{bus.deviceMac}</span>
                                </div>
                              ) : (
                                <div className="flex items-center space-x-1 text-muted-foreground">
                                  <WifiOff className="h-3 w-3" />
                                  <span className="text-xs">No Device</span>
                                </div>
                              )
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {isEditing ? (
                              <select
                                value={editBusForm.isAvailable ? 'true' : 'false'}
                                onChange={(e) => setEditBusForm(prev => ({ ...prev, isAvailable: e.target.value === 'true' }))}
                                className="px-2 py-1 border border-input rounded bg-background text-sm"
                              >
                                <option value="true">Available</option>
                                <option value="false">Unavailable</option>
                              </select>
                            ) : (
                              <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                                bus.isAvailable 
                                  ? 'bg-success-light text-success-light-foreground' 
                                  : 'bg-destructive-light text-destructive-light-foreground'
                              }`}>
                                {bus.isAvailable ? 'Available' : 'Unavailable'}
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {isEditing ? (
                              <div className="flex space-x-2">
                                <button
                                  onClick={() => handleEditBus(bus.id, editBusForm)}
                                  className="px-2 py-1 bg-success text-success-foreground rounded text-xs font-medium hover:bg-opacity-80 transition-colors"
                                >
                                  Save
                                </button>
                                <button
                                  onClick={() => {
                                    setEditingBus(null);
                                    setEditBusForm({});
                                  }}
                                  className="px-2 py-1 bg-muted text-muted-foreground rounded text-xs font-medium hover:bg-opacity-80 transition-colors"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <div className="flex space-x-2">
                                <button
                                  onClick={() => {
                                    setEditingBus(bus.id);
                                    setEditBusForm({
                                      busNo: bus.busNo,
                                      registrationNo: bus.registrationNo || '',
                                      route: bus.route,
                                      deviceMac: bus.deviceMac || '',
                                      isAvailable: bus.isAvailable
                                    });
                                  }}
                                  className="px-2 py-1 bg-primary text-primary-foreground rounded text-xs font-medium hover:bg-opacity-80 transition-colors flex items-center gap-1"
                                >
                                  <Edit className="h-3 w-3" />
                                  Edit
                                </button>
                                <button
                                  onClick={() => handleDeleteBus(bus.id)}
                                  className="px-2 py-1 bg-destructive text-destructive-foreground rounded text-xs font-medium hover:bg-opacity-80 transition-colors flex items-center gap-1"
                                >
                                  <Trash2 className="h-3 w-3" />
                                  Delete
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'addBus' && (
          <div className="bg-card rounded-xl shadow-lg border border-border">
            <div className="p-6 border-b border-border">
              <h2 className="text-xl font-semibold text-foreground">Add New Bus</h2>
            </div>
            <div className="p-6">
              <form onSubmit={handleAddBus} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Bus Number
                    </label>
                    <input
                      type="text"
                      required
                      value={newBus.busNo}
                      onChange={(e) => {
                        setNewBus(prev => ({ ...prev, busNo: e.target.value.toUpperCase() }));
                        if (validationErrors.busNo) {
                          setValidationErrors(prev => ({ ...prev, busNo: '' }));
                        }
                      }}
                      placeholder="e.g., 5A, 12B"
                      className={`w-full px-4 py-3 border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 ${
                        validationErrors.busNo ? 'border-red-500' : 'border-input'
                      }`}
                    />
                    {validationErrors.busNo && (
                      <p className="text-red-500 text-sm mt-1">{validationErrors.busNo}</p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Bus Registration Number
                    </label>
                    <input
                      type="text"
                      required
                      value={newBus.registrationNo}
                      onChange={(e) => {
                        setNewBus(prev => ({ ...prev, registrationNo: e.target.value.toUpperCase() }));
                        if (validationErrors.registrationNo) {
                          setValidationErrors(prev => ({ ...prev, registrationNo: '' }));
                        }
                      }}
                      placeholder="e.g., PB 65-BB4490"
                      className={`w-full px-4 py-3 border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 ${
                        validationErrors.registrationNo ? 'border-red-500' : 'border-input'
                      }`}
                    />
                    {validationErrors.registrationNo && (
                      <p className="text-red-500 text-sm mt-1">{validationErrors.registrationNo}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Route Description
                  </label>
                  <input
                    type="text"
                    required
                    value={newBus.route}
                    onChange={(e) => setNewBus(prev => ({ ...prev, route: e.target.value }))}
                    placeholder="e.g., Chandigarh to Amritsar"
                    className="w-full px-4 py-3 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Device MAC Address (Optional)
                  </label>
                  <input
                    type="text"
                    value={newBus.deviceMac}
                    onChange={(e) => setNewBus(prev => ({ ...prev, deviceMac: e.target.value }))}
                    placeholder="e.g., AA:BB:CC:DD:EE:FF"
                    className="w-full px-4 py-3 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-4">
                    <label className="block text-sm font-medium text-muted-foreground">
                      Bus Stops
                    </label>
                    <button
                      type="button"
                      onClick={addBusStop}
                      className="bg-accent text-accent-foreground px-3 py-1 rounded text-sm font-medium hover:bg-opacity-80 transition-colors"
                    >
                      Add Stop
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    {newBus.stops.map((stop, index) => (
                      <div key={index} className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 border border-border rounded-lg">
                        <input
                          type="text"
                          required
                          value={stop.name}
                          onChange={(e) => updateBusStop(index, 'name', e.target.value)}
                          placeholder="Stop name"
                          className="px-3 py-2 border border-input rounded bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                        <input
                          type="number"
                          step="0.000001"
                          required
                          value={stop.lat}
                          onChange={(e) => updateBusStop(index, 'lat', parseFloat(e.target.value))}
                          placeholder="Latitude"
                          className="px-3 py-2 border border-input rounded bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                        <input
                          type="number"
                          step="0.000001"
                          required
                          value={stop.lng}
                          onChange={(e) => updateBusStop(index, 'lng', parseFloat(e.target.value))}
                          placeholder="Longitude"
                          className="px-3 py-2 border border-input rounded bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                        <div className="flex space-x-2">
                          <input
                            type="text"
                            value={stop.eta}
                            onChange={(e) => updateBusStop(index, 'eta', e.target.value)}
                            placeholder="ETA"
                            className="flex-1 px-3 py-2 border border-input rounded bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                          />
                          {newBus.stops.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeBusStop(index)}
                              className="px-3 py-2 bg-destructive text-destructive-foreground rounded hover:bg-opacity-80 transition-colors"
                            >
                              ×
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-primary to-primary-hover text-primary-foreground px-6 py-3 rounded-lg font-medium shadow-md transition-all duration-200 hover:shadow-lg hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                >
                  {isLoading ? 'Adding Bus...' : 'Add Bus'}
                </button>
              </form>
            </div>
          </div>
        )}

        {activeTab === 'addDriver' && (
          <div className="bg-card rounded-xl shadow-lg border border-border">
            <div className="p-6 border-b border-border">
              <h2 className="text-xl font-semibold text-foreground">Add New Driver</h2>
            </div>
            <div className="p-6">
              <form onSubmit={handleAddDriver} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      required
                      value={newDriver.name}
                      onChange={(e) => setNewDriver(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g., Gurpreet Singh"
                      className="w-full px-4 py-3 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Driver ID
                    </label>
                    <input
                      type="text"
                      required
                      value={newDriver.driverId}
                      onChange={(e) => setNewDriver(prev => ({ ...prev, driverId: e.target.value }))}
                      placeholder="e.g., D001"
                      className="w-full px-4 py-3 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Username
                    </label>
                    <input
                      type="text"
                      required
                      value={newDriver.username}
                      onChange={(e) => setNewDriver(prev => ({ ...prev, username: e.target.value }))}
                      placeholder="e.g., gurpreet.singh"
                      className="w-full px-4 py-3 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Password
                    </label>
                    <input
                      type="password"
                      required
                      value={newDriver.password}
                      onChange={(e) => setNewDriver(prev => ({ ...prev, password: e.target.value }))}
                      placeholder="Enter password"
                      className="w-full px-4 py-3 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      required
                      value={newDriver.phone}
                      onChange={(e) => setNewDriver(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="e.g., +91-9876543210"
                      className="w-full px-4 py-3 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Assigned Bus Number
                    </label>
                    <input
                      type="text"
                      value={newDriver.assignedBusNumber}
                      onChange={(e) => setNewDriver(prev => ({ ...prev, assignedBusNumber: e.target.value }))}
                      placeholder="e.g., 5A"
                      className="w-full px-4 py-3 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-primary to-primary-hover text-primary-foreground px-6 py-3 rounded-lg font-medium shadow-md transition-all duration-200 hover:shadow-lg hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                >
                  {isLoading ? 'Adding Driver...' : 'Add Driver'}
                </button>
              </form>
            </div>
          </div>
        )}

        {activeTab === 'viewDrivers' && (
          <DriverList
            drivers={drivers}
            buses={buses}
            onEdit={handleEditDriver}
            onDelete={handleDeleteDriver}
            isLoading={isLoading}
          />
        )}

        {activeTab === 'analytics' && (
          <Analytics />
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;