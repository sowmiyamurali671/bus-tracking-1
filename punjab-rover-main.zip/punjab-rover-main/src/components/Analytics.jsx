import { useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line 
} from 'recharts';
import { TrendingUp, Search, CheckCircle, XCircle } from 'lucide-react';
import apiService from '../services/api';

const Analytics = () => {
  const [analyticsData, setAnalyticsData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    setIsLoading(true);
    try {
      const response = await apiService.getSearchAnalytics();
      if (response.success) {
        setAnalyticsData(response.data);
      } else {
        setError(response.error || 'Failed to load analytics');
      }
    } catch (err) {
      setError('Failed to load analytics');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent mx-auto"></div>
        <p className="mt-2 text-muted-foreground">Loading analytics...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12 text-destructive">
        <XCircle className="h-12 w-12 mx-auto mb-2" />
        <p>{error}</p>
      </div>
    );
  }

  if (error || !analyticsData) {

    return (
      <div className="text-center py-12 text-destructive">
        <XCircle className="h-12 w-12 mx-auto mb-2" />
        <p>{error || 'Failed to load analytics'}</p>
      </div>
    );
  }

  const pieData = [
    { name: 'Successful', value: analyticsData.totalSuccess, color: '#10b981' },
    { name: 'Failed', value: analyticsData.totalFail, color: '#ef4444' },
    { name: 'Repeated', value: analyticsData.totalRepeated, color: '#f59e0b' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2 mb-6">
        <TrendingUp className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-semibold text-foreground">Search Analytics</h2>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
        <div className="bg-white shadow-md rounded-xl p-4 hover:shadow-lg transition">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Searches</p>
              <p className="text-2xl font-bold text-foreground">
                {analyticsData.totalSuccess + analyticsData.totalFail}
              </p>
            </div>
            <Search className="h-8 w-8 text-primary" />
          </div>
        </div>

        <div className="bg-white shadow-md rounded-xl p-4 hover:shadow-lg transition">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Successful</p>
              <p className="text-2xl font-bold text-success">{analyticsData.totalSuccess}</p>
            </div>
            <CheckCircle className="h-8 w-8 text-success" />
          </div>
        </div>

        <div className="bg-white shadow-md rounded-xl p-4 hover:shadow-lg transition">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Failed</p>
              <p className="text-2xl font-bold text-destructive">{analyticsData.totalFail}</p>
            </div>
            <XCircle className="h-8 w-8 text-destructive" />
          </div>
        </div>

        <div className="bg-white shadow-md rounded-xl p-4 hover:shadow-lg transition">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Success Rate</p>
              <p className="text-2xl font-bold text-primary">{analyticsData.successRate}%</p>
            </div>
            <TrendingUp className="h-8 w-8 text-primary" />
          </div>
        </div>

        <div className="bg-white shadow-md rounded-xl p-4 hover:shadow-lg transition">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Repeated</p>
              <p className="text-2xl font-bold text-orange-500">{analyticsData.totalRepeated}</p>
            </div>
            <Search className="h-8 w-8 text-orange-500" />
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Bar Chart */}
        <div className="bg-white shadow-md rounded-xl p-6 hover:shadow-lg transition">
          <h3 className="text-lg font-semibold text-foreground mb-4">Daily Search Trends</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData.dailyData || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="successful" fill="#10b981" name="Successful" />
                <Bar dataKey="failed" fill="#ef4444" name="Failed" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie Chart */}
        <div className="bg-white shadow-md rounded-xl p-6 hover:shadow-lg transition">
          <h3 className="text-lg font-semibold text-foreground mb-4">Success Rate Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center space-x-6 mt-4">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-success rounded-full mr-2"></div>
              <span className="text-sm text-muted-foreground">Successful ({analyticsData.successRate}%)</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-destructive rounded-full mr-2"></div>
              <span className="text-sm text-muted-foreground">Failed ({100 - analyticsData.successRate}%)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Search Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Successful Searches Table */}
        <div className="bg-white shadow-md rounded-xl hover:shadow-lg transition">
          <div className="p-4 border-b border-border">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-success" />
              Successful Searches
            </h3>
          </div>
          <div className="max-h-96 overflow-y-auto">
            <table className="w-full">
              <thead className="sticky top-0 bg-white">
                <tr className="border-b border-border">
                  <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Route</th>
                  <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Time</th>
                </tr>
              </thead>
              <tbody>
                {(analyticsData.successfulSearches || []).map((log, index) => (
                  <tr key={index} className="border-b border-border odd:bg-slate-50">
                    <td className="py-2 px-4">
                      <span className="font-medium text-foreground text-sm">{log.from} → {log.to}</span>
                    </td>
                    <td className="py-2 px-4">
                      <span className="text-xs text-muted-foreground">{log.timestamp}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Failed Searches Table */}
        <div className="bg-white shadow-md rounded-xl hover:shadow-lg transition">
          <div className="p-4 border-b border-border">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <XCircle className="h-5 w-5 text-destructive" />
              Failed Searches
            </h3>
          </div>
          <div className="max-h-96 overflow-y-auto">
            <table className="w-full">
              <thead className="sticky top-0 bg-white">
                <tr className="border-b border-border">
                  <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Route</th>
                  <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Time</th>
                </tr>
              </thead>
              <tbody>
                {(analyticsData.failedSearches || []).map((log, index) => (
                  <tr key={index} className="border-b border-border odd:bg-slate-50">
                    <td className="py-2 px-4">
                      <span className="font-medium text-foreground text-sm">{log.from} → {log.to}</span>
                    </td>
                    <td className="py-2 px-4">
                      <span className="text-xs text-muted-foreground">{log.timestamp}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Repeated Searches Table */}
        <div className="bg-white shadow-md rounded-xl hover:shadow-lg transition">
          <div className="p-4 border-b border-border">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <Search className="h-5 w-5 text-orange-500" />
              Repeated Searches
            </h3>
          </div>
          <div className="max-h-96 overflow-y-auto">
            <table className="w-full">
              <thead className="sticky top-0 bg-white">
                <tr className="border-b border-border">
                  <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Route</th>
                  <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Status</th>
                  <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Time</th>
                </tr>
              </thead>
              <tbody>
                {(analyticsData.repeatedSearches || []).map((log, index) => (
                  <tr key={index} className="border-b border-border odd:bg-slate-50">
                    <td className="py-2 px-4">
                      <span className="font-medium text-foreground text-sm">{log.from} → {log.to}</span>
                    </td>
                    <td className="py-2 px-4">
                      <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
                        log.status === 'success' 
                          ? 'bg-success/20 text-success' 
                          : 'bg-destructive/20 text-destructive'
                      }`}>
                        {log.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-2 px-4">
                      <span className="text-xs text-muted-foreground">{log.timestamp}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;