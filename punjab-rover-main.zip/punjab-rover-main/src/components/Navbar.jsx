import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleDriverClick = () => {
    navigate('/driver/login');
    setIsMenuOpen(false);
  };

  const handleAdminClick = () => {
    navigate('/admin/login');
    setIsMenuOpen(false);
  };

  const handleHomeClick = () => {
    navigate('/');
    setIsMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-card shadow-lg border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo/Brand */}
          <div 
            className="flex-shrink-0 cursor-pointer"
            onClick={handleHomeClick}
          >
            <h1 className="text-2xl font-extrabold tracking-tight text-primary">
              Punjab Bus Tracking
            </h1>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <button
                onClick={handleDriverClick}
                className="bg-gradient-to-r from-primary to-primary-hover text-primary-foreground px-6 py-2 rounded-2xl font-medium shadow-md transition-all duration-200 hover:shadow-lg hover:scale-105"
              >
                Driver
              </button>
              <button
                onClick={handleAdminClick}
                className="bg-gradient-to-r from-accent to-accent-hover text-accent-foreground px-6 py-2 rounded-2xl font-medium shadow-md transition-all duration-200 hover:shadow-lg hover:scale-105"
              >
                Admin
              </button>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className="p-2 rounded-lg text-foreground hover:text-primary hover:bg-muted transition-colors duration-200"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {isMenuOpen && (
        <div className="md:hidden animate-slide-up">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-card border-t border-border">
            <button
              onClick={handleDriverClick}
              className="w-full text-left block px-3 py-2 rounded-lg text-base font-medium text-foreground hover:text-primary hover:bg-muted transition-colors duration-200"
            >
              Driver Login
            </button>
            <button
              onClick={handleAdminClick}
              className="w-full text-left block px-3 py-2 rounded-lg text-base font-medium text-foreground hover:text-primary hover:bg-muted transition-colors duration-200"
            >
              Admin Login
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;