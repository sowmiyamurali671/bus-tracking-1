// Sample data for Punjab Bus Tracking Application

export const buses = [
  {
    id: "BUS001",
    busNo: "5A",
    registrationNo: "PB 65-AA1234",
    route: "Chandigarh to Amritsar",
    stops: [
      { name: "ISBT Chandigarh", lat: 30.7333, lng: 76.7794, eta: "0 min" },
      { name: "Ambala Cantt", lat: 30.3752, lng: 76.7821, eta: "45 min" },
      { name: "Rajpura", lat: 30.4858, lng: 76.5944, eta: "75 min" },
      { name: "Patiala", lat: 30.3398, lng: 76.3869, eta: "105 min" },
      { name: "Sangrur", lat: 30.2458, lng: 75.8421, eta: "150 min" },
      { name: "Amritsar", lat: 31.6340, lng: 74.8723, eta: "210 min" }
    ],
    currentLocation: { lat: 30.4858, lng: 76.5944 },
    speed: 45,
    nextStop: "Patiala",
    lastStopCrossed: "Rajpura",
    eta: "35 min",
    isAvailable: true,
    deviceMac: "AA:BB:CC:DD:EE:01",
    lastSeen: new Date().toISOString(),
    driver: null
  },
  {
    id: "BUS002", 
    busNo: "12B",
    registrationNo: "PB 02-BB5678",
    route: "Ludhiana to Jalandhar",
    stops: [
      { name: "Ludhiana Bus Stand", lat: 30.9010, lng: 75.8573, eta: "0 min" },
      { name: "Khanna", lat: 30.7046, lng: 76.2173, eta: "30 min" },
      { name: "Doraha", lat: 30.8126, lng: 76.0244, eta: "45 min" },
      { name: "Phillaur", lat: 31.0180, lng: 75.7886, eta: "75 min" },
      { name: "Jalandhar", lat: 31.3260, lng: 75.5762, eta: "105 min" }
    ],
    currentLocation: { lat: 30.8126, lng: 76.0244 },
    speed: 52,
    nextStop: "Phillaur", 
    lastStopCrossed: "Doraha",
    eta: "28 min",
    isAvailable: true,
    deviceMac: "BB:CC:DD:EE:FF:02",
    lastSeen: new Date().toISOString(),
    driver: "DRV001"
  },
  {
    id: "BUS003",
    busNo: "6A",
    registrationNo: "PB 03-CC9012", 
    route: "Mohali to Bathinda",
    stops: [
      { name: "Mohali Phase 8", lat: 30.7046, lng: 76.7179, eta: "0 min" },
      { name: "Kharar", lat: 30.7408, lng: 76.6469, eta: "20 min" },
      { name: "Morinda", lat: 30.7923, lng: 76.4993, eta: "45 min" },
      { name: "Sirhind", lat: 30.6443, lng: 76.3844, eta: "75 min" },
      { name: "Nabha", lat: 30.3764, lng: 76.1513, eta: "120 min" },
      { name: "Bathinda", lat: 30.2118, lng: 74.9455, eta: "180 min" }
    ],
    currentLocation: { lat: 30.7923, lng: 76.4993 },
    speed: 0,
    nextStop: "Sirhind",
    lastStopCrossed: "Morinda", 
    eta: "12 min",
    isAvailable: false,
    deviceMac: "CC:DD:EE:FF:AA:03",
    lastSeen: new Date(Date.now() - 300000).toISOString(), // 5 minutes ago
    driver: "DRV002"
  },
  {
    id: "BUS004",
    busNo: "8C",
    registrationNo: "PB 04-DD3456",
    route: "Patiala to Shimla",
    stops: [
      { name: "Patiala Bus Stand", lat: 30.3398, lng: 76.3869, eta: "0 min" },
      { name: "Rajpura", lat: 30.4858, lng: 76.5944, eta: "35 min" },
      { name: "Ambala", lat: 30.3782, lng: 76.7767, eta: "65 min" },
      { name: "Kalka", lat: 30.8398, lng: 76.9367, eta: "95 min" },
      { name: "Solan", lat: 30.9045, lng: 77.1006, eta: "135 min" },
      { name: "Shimla", lat: 31.1048, lng: 77.1734, eta: "195 min" }
    ],
    currentLocation: { lat: 30.8398, lng: 76.9367 },
    speed: 38,
    nextStop: "Solan",
    lastStopCrossed: "Kalka",
    eta: "42 min",
    isAvailable: true,
    deviceMac: "DD:EE:FF:AA:BB:04",
    lastSeen: new Date().toISOString(),
    driver: null
  },
  {
    id: "BUS005",
    busNo: "15A",
    registrationNo: "PB 05-EE7890",
    route: "Ferozepur to Chandigarh", 
    stops: [
      { name: "Ferozepur Cantt", lat: 30.9247, lng: 74.6131, eta: "0 min" },
      { name: "Faridkot", lat: 30.6735, lng: 74.7555, eta: "45 min" },
      { name: "Bathinda", lat: 30.2118, lng: 74.9455, eta: "90 min" },
      { name: "Mansa", lat: 29.9988, lng: 75.3933, eta: "120 min" },
      { name: "Sangrur", lat: 30.2458, lng: 75.8421, eta: "150 min" },
      { name: "Patiala", lat: 30.3398, lng: 76.3869, eta: "210 min" },
      { name: "Chandigarh", lat: 30.7333, lng: 76.7794, eta: "270 min" }
    ],
    currentLocation: { lat: 30.2118, lng: 74.9455 },
    speed: 48,
    nextStop: "Mansa",
    lastStopCrossed: "Bathinda",
    eta: "25 min", 
    isAvailable: true,
    deviceMac: "EE:FF:AA:BB:CC:05",
    lastSeen: new Date().toISOString(),
    driver: "DRV003"
  },
  {
    id: "BUS006",
    busNo: "20B",
    registrationNo: "PB 06-FF2468",
    route: "Amritsar to Delhi",
    stops: [
      { name: "Golden Temple Complex", lat: 31.6340, lng: 74.8723, eta: "0 min" },
      { name: "Tarn Taran", lat: 31.4516, lng: 74.9285, eta: "30 min" },
      { name: "Kapurthala", lat: 31.380, lng: 75.3802, eta: "75 min" },
      { name: "Jalandhar", lat: 31.3260, lng: 75.5762, eta: "105 min" },
      { name: "Ludhiana", lat: 30.9010, lng: 75.8573, eta: "165 min" },
      { name: "Ambala", lat: 30.3782, lng: 76.7767, eta: "240 min" },
      { name: "Panipat", lat: 29.3909, lng: 76.9635, eta: "300 min" },
      { name: "Delhi ISBT", lat: 28.6692, lng: 77.2324, eta: "360 min" }
    ],
    currentLocation: { lat: 31.3260, lng: 75.5762 },
    speed: 55,
    nextStop: "Ludhiana",
    lastStopCrossed: "Jalandhar",
    eta: "58 min",
    isAvailable: false,
    deviceMac: null,
    lastSeen: new Date(Date.now() - 600000).toISOString(), // 10 minutes ago
    driver: null
  }
];

export const drivers = [
  {
    id: "DRV001",
    name: "Gurpreet Singh",
    driverId: "D001",
    username: "gurpreet.singh",
    password: "driver123", // In real app, this would be hashed
    phone: "+91-9876543210",
    experience: "8 years",
    currentBus: "BUS002",
    isActive: true
  },
  {
    id: "DRV002", 
    name: "Manpreet Kaur",
    driverId: "D002",
    username: "manpreet.kaur",
    password: "driver456",
    phone: "+91-9876543211",
    experience: "5 years", 
    currentBus: "BUS003",
    isActive: false
  },
  {
    id: "DRV003",
    name: "Hardeep Singh",
    driverId: "D003", 
    username: "hardeep.singh",
    password: "driver789",
    phone: "+91-9876543212",
    experience: "12 years",
    currentBus: "BUS005", 
    isActive: true
  },
  {
    id: "DRV004",
    name: "Simran Kaur",
    driverId: "D004",
    username: "simran.kaur",
    password: "driver101",
    phone: "+91-9876543213", 
    experience: "3 years",
    currentBus: null,
    isActive: true
  },
  {
    id: "DRV005",
    name: "Rajdeep Singh",
    driverId: "D005",
    username: "rajdeep.singh", 
    password: "driver202",
    phone: "+91-9876543214",
    experience: "10 years",
    currentBus: null,
    isActive: true
  }
];

export const adminUsers = [
  {
    id: "ADMIN001",
    username: "admin",
    password: "admin123", // In real app, this would be hashed
    name: "Punjab Transport Admin",
    role: "super_admin"
  },
  {
    id: "ADMIN002", 
    username: "supervisor",
    password: "super123",
    name: "Regional Supervisor",
    role: "supervisor"
  }
];

// Helper function to get bus by ID
export const getBusById = (busId) => {
  return buses.find(bus => bus.id === busId);
};

// Helper function to get driver by ID
export const getDriverById = (driverId) => {
  return drivers.find(driver => driver.id === driverId);
};

// Helper function to get available buses near a location
export const getBusesNearLocation = (lat, lng, maxDistance = 50) => {
  return buses.filter(bus => {
    if (!bus.isAvailable) return false;
    
    // Simple distance calculation (in practice, use proper geospatial library)
    const distance = Math.sqrt(
      Math.pow(bus.currentLocation.lat - lat, 2) + 
      Math.pow(bus.currentLocation.lng - lng, 2)
    ) * 111; // Rough conversion to km
    
    return distance <= maxDistance;
  });
};