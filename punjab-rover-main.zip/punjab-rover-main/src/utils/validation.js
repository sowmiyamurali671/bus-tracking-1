// Validation utilities for Punjab Bus Tracking

export const validateBusNumber = (busNo) => {
  // Format: 5A, 6A, 5B, etc. (1-2 digits + single uppercase letter)
  const busNoPattern = /^\d{1,2}[A-Z]$/;
  return busNoPattern.test(busNo);
};

export const validateRegistrationNumber = (registrationNo) => {
  // Format: PB 65-BB4490 (PB 65-XX0000)
  const regPattern = /^PB \d{2}-[A-Z]{2}\d{4}$/;
  return regPattern.test(registrationNo);
};

export const getBusNumberError = (busNo) => {
  if (!busNo) return 'Bus number is required';
  if (!validateBusNumber(busNo)) {
    return 'Bus number must be 1-2 digits followed by a single uppercase letter (e.g., 5A, 12B)';
  }
  return '';
};

export const getRegistrationNumberError = (registrationNo) => {
  if (!registrationNo) return 'Registration number is required';
  if (!validateRegistrationNumber(registrationNo)) {
    return 'Registration number must follow format: PB 65-XX0000 (e.g., PB 65-BB4490)';
  }
  return '';
};