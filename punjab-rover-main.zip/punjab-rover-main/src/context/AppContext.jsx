import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { buses as seedBuses, drivers as seedDrivers, adminUsers as seedAdminUsers } from '../data/seed.js';

const AppContext = createContext();

// Initial state
const initialState = {
  buses: [],
  drivers: [],
  adminUsers: [],
  searchLogs: [],
  lastUpdated: Date.now()
};

// Action types
export const actionTypes = {
  // Bus actions
  ADD_BUS: 'ADD_BUS',
  EDIT_BUS: 'EDIT_BUS',
  DELETE_BUS: 'DELETE_BUS',
  TOGGLE_BUS_AVAILABILITY: 'TOGGLE_BUS_AVAILABILITY',
  ASSIGN_DEVICE: 'ASSIGN_DEVICE',
  UPDATE_BUS_LOCATION: 'UPDATE_BUS_LOCATION',
  
  // Driver actions
  ADD_DRIVER: 'ADD_DRIVER',
  EDIT_DRIVER: 'EDIT_DRIVER',
  DELETE_DRIVER: 'DELETE_DRIVER',
  ASSIGN_DRIVER_TO_BUS: 'ASSIGN_DRIVER_TO_BUS',
  ASSIGN_BUS_TO_DRIVER: 'ASSIGN_BUS_TO_DRIVER',
  CONNECT_DRIVER_TO_BUS: 'CONNECT_DRIVER_TO_BUS',
  DISCONNECT_DRIVER_FROM_BUS: 'DISCONNECT_DRIVER_FROM_BUS',
  
  // Search actions
  LOG_SEARCH: 'LOG_SEARCH',
  
  // Utility actions
  CLEAR_DATA: 'CLEAR_DATA',
  LOAD_DATA: 'LOAD_DATA'
};

// Reducer function
const appReducer = (state, action) => {
  switch (action.type) {
    case actionTypes.ADD_BUS: {
      const newBus = {
        id: `BUS${String(state.buses.length + 1).padStart(3, '0')}`,
        ...action.payload,
        currentLocation: action.payload.currentLocation || { lat: 30.7333, lng: 76.7794 },
        speed: 0,
        nextStop: action.payload.stops?.[0]?.name || '',
        lastStopCrossed: '',
        eta: '0 min',
        isAvailable: true,
        deviceMac: action.payload.deviceMac || null,
        lastSeen: new Date().toISOString(),
        driver: null
      };
      return {
        ...state,
        buses: [...state.buses, newBus],
        lastUpdated: Date.now()
      };
    }

    case actionTypes.EDIT_BUS: {
      return {
        ...state,
        buses: state.buses.map(bus =>
          bus.id === action.payload.id
            ? { ...bus, ...action.payload.data, lastSeen: new Date().toISOString() }
            : bus
        ),
        lastUpdated: Date.now()
      };
    }

    case actionTypes.DELETE_BUS: {
      const busToDelete = state.buses.find(bus => bus.id === action.payload.busId);
      let updatedDrivers = state.drivers;
      
      // Remove bus assignment from drivers
      if (busToDelete && busToDelete.driver) {
        updatedDrivers = state.drivers.map(driver =>
          driver.id === busToDelete.driver
            ? { ...driver, currentBus: null }
            : driver
        );
      }
      
      return {
        ...state,
        buses: state.buses.filter(bus => bus.id !== action.payload.busId),
        drivers: updatedDrivers,
        lastUpdated: Date.now()
      };
    }

    case actionTypes.TOGGLE_BUS_AVAILABILITY: {
      return {
        ...state,
        buses: state.buses.map(bus =>
          bus.id === action.payload.busId
            ? { ...bus, isAvailable: action.payload.isAvailable, lastSeen: new Date().toISOString() }
            : bus
        ),
        lastUpdated: Date.now()
      };
    }

    case actionTypes.ASSIGN_DEVICE: {
      return {
        ...state,
        buses: state.buses.map(bus =>
          bus.id === action.payload.busId
            ? { ...bus, deviceMac: action.payload.deviceMac, lastSeen: new Date().toISOString() }
            : bus
        ),
        lastUpdated: Date.now()
      };
    }

    case actionTypes.UPDATE_BUS_LOCATION: {
      return {
        ...state,
        buses: state.buses.map(bus =>
          bus.id === action.payload.busId
            ? {
                ...bus,
                currentLocation: {
                  lat: action.payload.lat,
                  lng: action.payload.lng
                },
                speed: action.payload.speed || bus.speed,
                lastSeen: new Date().toISOString()
              }
            : bus
        ),
        lastUpdated: Date.now()
      };
    }

    case actionTypes.ADD_DRIVER: {
      const newDriver = {
        id: `DRV${String(state.drivers.length + 1).padStart(3, '0')}`,
        ...action.payload,
        currentBus: null,
        isActive: true
      };
      return {
        ...state,
        drivers: [...state.drivers, newDriver],
        lastUpdated: Date.now()
      };
    }

    case actionTypes.EDIT_DRIVER: {
      return {
        ...state,
        drivers: state.drivers.map(driver =>
          driver.id === action.payload.id
            ? { ...driver, ...action.payload.data }
            : driver
        ),
        lastUpdated: Date.now()
      };
    }

    case actionTypes.DELETE_DRIVER: {
      const driverToDelete = state.drivers.find(driver => driver.id === action.payload.driverId);
      let updatedBuses = state.buses;
      
      // Remove driver assignment from buses
      if (driverToDelete && driverToDelete.currentBus) {
        updatedBuses = state.buses.map(bus =>
          bus.id === driverToDelete.currentBus
            ? { ...bus, driver: null }
            : bus
        );
      }
      
      return {
        ...state,
        drivers: state.drivers.filter(driver => driver.id !== action.payload.driverId),
        buses: updatedBuses,
        lastUpdated: Date.now()
      };
    }

    case actionTypes.CONNECT_DRIVER_TO_BUS: {
      const { busId, driverId } = action.payload;
      
      // Update bus with driver assignment
      const updatedBuses = state.buses.map(bus =>
        bus.id === busId
          ? { ...bus, driver: driverId, lastSeen: new Date().toISOString() }
          : bus
      );
      
      // Update driver with bus assignment
      const updatedDrivers = state.drivers.map(driver =>
        driver.id === driverId
          ? { ...driver, currentBus: busId, isActive: true }
          : driver
      );
      
      return {
        ...state,
        buses: updatedBuses,
        drivers: updatedDrivers,
        lastUpdated: Date.now()
      };
    }

    case actionTypes.DISCONNECT_DRIVER_FROM_BUS: {
      const { busId, driverId } = action.payload;
      
      // Update bus to remove driver assignment
      const updatedBuses = state.buses.map(bus =>
        bus.id === busId
          ? { ...bus, driver: null, lastSeen: new Date().toISOString() }
          : bus
      );
      
      // Update driver to remove bus assignment
      const updatedDrivers = state.drivers.map(driver =>
        driver.id === driverId
          ? { ...driver, currentBus: null }
          : driver
      );
      
      return {
        ...state,
        buses: updatedBuses,
        drivers: updatedDrivers,
        lastUpdated: Date.now()
      };
    }

    case actionTypes.LOG_SEARCH: {
      const { from, to, fromLat, fromLng, timestamp, status } = action.payload;
      
      // Normalize locations for comparison (remove extra spaces, convert to lowercase)
      const normalizeLocation = (location) => location.toLowerCase().trim().replace(/\s+/g, ' ');
      const normalizedFrom = normalizeLocation(from);
      const normalizedTo = normalizeLocation(to);
      
      // Check if this is a repeated search (same from+to within last 24 hours)
      const twentyFourHoursAgo = timestamp - (24 * 60 * 60 * 1000);
      const existingSearch = state.searchLogs.find(log => 
        normalizeLocation(log.from) === normalizedFrom &&
        normalizeLocation(log.to) === normalizedTo &&
        log.timestamp > twentyFourHoursAgo
      );
      
      const searchLog = {
        id: `SEARCH_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        from,
        to,
        fromLat,
        fromLng,
        timestamp,
        status,
        isRepeated: !!existingSearch
      };
      
      return {
        ...state,
        searchLogs: [...state.searchLogs, searchLog],
        lastUpdated: Date.now()
      };
    }

    case actionTypes.CLEAR_DATA: {
      const resetState = {
        buses: [...seedBuses],
        drivers: [...seedDrivers],
        adminUsers: [...seedAdminUsers],
        searchLogs: [],
        lastUpdated: Date.now()
      };
      return resetState;
    }

    case actionTypes.LOAD_DATA: {
      return {
        ...action.payload,
        lastUpdated: Date.now()
      };
    }

    default:
      return state;
  }
};

// Local storage key
const STORAGE_KEY = 'pbt_app_state';

// App Context Provider
export const AppProvider = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Load initial data from localStorage or seed data
  useEffect(() => {
    try {
      const savedState = localStorage.getItem(STORAGE_KEY);
      if (savedState) {
        const parsedState = JSON.parse(savedState);
        dispatch({ type: actionTypes.LOAD_DATA, payload: parsedState });
      } else {
        // Load seed data if no saved state
        dispatch({
          type: actionTypes.LOAD_DATA,
          payload: {
            buses: [...seedBuses],
            drivers: [...seedDrivers],
            adminUsers: [...seedAdminUsers],
            searchLogs: []
          }
        });
      }
    } catch (error) {
      console.error('Error loading state from localStorage:', error);
      // Load seed data on error
      dispatch({
        type: actionTypes.LOAD_DATA,
        payload: {
          buses: [...seedBuses],
          drivers: [...seedDrivers],
          adminUsers: [...seedAdminUsers],
          searchLogs: []
        }
      });
    }
  }, []);

  // Save state to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      // Broadcast state update for any components that might need it
      window.dispatchEvent(new CustomEvent('pbt_state_updated', { detail: state }));
    } catch (error) {
      console.error('Error saving state to localStorage:', error);
    }
  }, [state]);

  // Action creators
  const actions = {
    // Bus actions
    addBus: (busData) => dispatch({ type: actionTypes.ADD_BUS, payload: busData }),
    editBus: (id, data) => dispatch({ type: actionTypes.EDIT_BUS, payload: { id, data } }),
    deleteBus: (busId) => dispatch({ type: actionTypes.DELETE_BUS, payload: { busId } }),
    toggleBusAvailability: (busId, isAvailable) => 
      dispatch({ type: actionTypes.TOGGLE_BUS_AVAILABILITY, payload: { busId, isAvailable } }),
    assignDevice: (busId, deviceMac) => 
      dispatch({ type: actionTypes.ASSIGN_DEVICE, payload: { busId, deviceMac } }),
    updateBusLocation: (busId, lat, lng, speed) => 
      dispatch({ type: actionTypes.UPDATE_BUS_LOCATION, payload: { busId, lat, lng, speed } }),

    // Driver actions
    addDriver: (driverData) => dispatch({ type: actionTypes.ADD_DRIVER, payload: driverData }),
    editDriver: (id, data) => dispatch({ type: actionTypes.EDIT_DRIVER, payload: { id, data } }),
    deleteDriver: (driverId) => dispatch({ type: actionTypes.DELETE_DRIVER, payload: { driverId } }),
    connectDriverToBus: (busId, driverId) => 
      dispatch({ type: actionTypes.CONNECT_DRIVER_TO_BUS, payload: { busId, driverId } }),
    disconnectDriverFromBus: (busId, driverId) => 
      dispatch({ type: actionTypes.DISCONNECT_DRIVER_FROM_BUS, payload: { busId, driverId } }),

    // Search actions
    logSearch: (from, to, fromLat, fromLng, status) => 
      dispatch({ 
        type: actionTypes.LOG_SEARCH, 
        payload: { from, to, fromLat, fromLng, timestamp: Date.now(), status } 
      }),

    // Utility actions
    clearData: () => dispatch({ type: actionTypes.CLEAR_DATA }),
  };

  const value = {
    state,
    actions,
    dispatch
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};

// Custom hook to use the app context
export const useAppState = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppState must be used within an AppProvider');
  }
  return context;
};

export default AppContext;