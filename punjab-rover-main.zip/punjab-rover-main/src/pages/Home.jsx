import { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import SearchForm from '../components/SearchForm';
import BusCard from '../components/BusCard';
import BusModal from '../components/BusModal';
import BackButton from '../components/BackButton';
import apiService, { setAppContext } from '../services/api';
import wsService from '../services/ws';
import { useAppState } from '../context/AppContext';

const Home = () => {
  const { state, actions } = useAppState();
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedBus, setSelectedBus] = useState(null);
  const [passengerLocation, setPassengerLocation] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);

  // Set context for api service
  useEffect(() => {
    setAppContext(actions, state);
  }, [actions, state]);

  const handleSearch = async (searchData) => {
    setIsSearching(true);
    setHasSearched(true);
    
    // Store passenger location for map display
    setPassengerLocation({
      lat: searchData.fromLat,
      lng: searchData.fromLng,
      address: searchData.fromLocation
    });

    try {
      const response = await apiService.searchBuses(
        searchData.fromLat,
        searchData.fromLng,
        searchData.toLocation
      );

      if (response.success) {
        setSearchResults(response.data);
        
        // Connect to WebSocket for real-time updates if not already connected
        if (!wsService.getConnectionStatus().isConnected) {
          wsService.connect();
        }
      } else {
        console.error('Search failed:', response.error);
        setSearchResults([]);
      }
    } catch (error) {
      console.error('Search error:', error);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleBusCardClick = (bus) => {
    setSelectedBus(bus);
  };

  const handleCloseBusModal = () => {
    setSelectedBus(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <BackButton />
      <Navbar />
      
      {/* Main Content */}
      <main className="pt-20 pb-8">
        {/* Hero Section with Search */}
        <section className="py-12 px-4">
          <div className="max-w-4xl mx-auto text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-foreground mb-4">
              Track Your Bus in <span className="text-primary">Real-Time</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Find and track Punjab buses with live locations, accurate ETAs, and route information.
            </p>
          </div>
          
          <SearchForm onSearch={handleSearch} isLoading={isSearching} />
        </section>

        {/* Search Results */}
        {hasSearched && (
          <section className="px-4 pb-8">
            <div className="max-w-7xl mx-auto">
              {isSearching ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent mx-auto mb-4"></div>
                  <p className="text-lg text-muted-foreground">Searching for buses...</p>
                </div>
              ) : searchResults.length > 0 ? (
                <>
                  <div className="text-center mb-8">
                    <h2 className="text-2xl font-bold text-foreground mb-2">
                      Available Buses
                    </h2>
                    <p className="text-muted-foreground">
                      Found {searchResults.length} bus{searchResults.length !== 1 ? 'es' : ''} for your route
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {searchResults.map((bus) => (
                      <BusCard
                        key={bus.id}
                        bus={bus}
                        onCardClick={handleBusCardClick}
                      />
                    ))}
                  </div>
                </>
              ) : (
                <div className="text-center py-12">
                  <div className="mb-4">
                    <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl">🚌</span>
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">
                      No Buses Found
                    </h3>
                    <p className="text-muted-foreground max-w-md mx-auto">
                      We couldn't find any buses for your search. Try searching for a different destination or check back later.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </section>
        )}

        {/* Features Section (shown when no search has been made) */}
        {!hasSearched && (
          <section className="px-4 py-16">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-foreground mb-4">
                  Why Choose Punjab Bus Tracking?
                </h2>
                <p className="text-lg text-muted-foreground">
                  Experience the future of public transportation with our advanced tracking system
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center p-6">
                  <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl text-primary-foreground">📍</span>
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    Real-Time Tracking
                  </h3>
                  <p className="text-muted-foreground">
                    Get live bus locations and accurate arrival times with GPS precision
                  </p>
                </div>
                
                <div className="text-center p-6">
                  <div className="w-16 h-16 bg-accent rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl text-accent-foreground">🗺️</span>
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    Interactive Maps
                  </h3>
                  <p className="text-muted-foreground">
                    View bus routes, stops, and your location on detailed interactive maps
                  </p>
                </div>
                
                <div className="text-center p-6">
                  <div className="w-16 h-16 bg-success rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl text-success-foreground">⏰</span>
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    Smart ETAs
                  </h3>
                  <p className="text-muted-foreground">
                    Plan your journey with intelligent arrival time predictions
                  </p>
                </div>
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Bus Details Modal */}
      <BusModal
        bus={selectedBus}
        passengerLocation={passengerLocation}
        isOpen={!!selectedBus}
        onClose={handleCloseBusModal}
      />
    </div>
  );
};

export default Home;