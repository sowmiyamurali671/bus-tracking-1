import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from '../components/LoginForm';
import DriverDashboard from '../components/DriverDashboard';
import BackButton from '../components/BackButton';
import apiService from '../services/api';

const DriverLogin = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [driver, setDriver] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async (credentials) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await apiService.driverLogin(credentials);
      
      if (response.success) {
        setDriver(response.data.driver);
        setIsLoggedIn(true);
        apiService.setToken(response.data.token);
      } else {
        setError(response.error || 'Login failed');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setDriver(null);
    apiService.logout();
    setError(null);
  };

  if (isLoggedIn && driver) {
    return (
      <DriverDashboard 
        driver={driver} 
        onLogout={handleLogout}
      />
    );
  }

  return (
    <div>
      <BackButton />
      <LoginForm
        title="Driver Login"
        onSubmit={handleLogin}
        isLoading={isLoading}
        error={error}
        primaryColor="primary"
      />
    </div>
  );
};

export default DriverLogin;