import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from '../components/LoginForm';
import AdminDashboard from '../components/AdminDashboard';
import BackButton from '../components/BackButton';
import apiService from '../services/api';

const AdminLogin = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [admin, setAdmin] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async (credentials) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await apiService.adminLogin(credentials);
      
      if (response.success) {
        setAdmin(response.data.admin);
        setIsLoggedIn(true);
        apiService.setToken(response.data.token);
      } else {
        setError(response.error || 'Login failed');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setAdmin(null);
    apiService.logout();
    setError(null);
  };

  if (isLoggedIn && admin) {
    return (
      <AdminDashboard 
        admin={admin} 
        onLogout={handleLogout}
      />
    );
  }

  return (
    <div>
      <BackButton />
      <LoginForm
        title="Admin Login"
        onSubmit={handleLogin}
        isLoading={isLoading}
        error={error}
        primaryColor="accent"
      />
    </div>
  );
};

export default AdminLogin;